# 스타일.json — 레퍼런스 해석 결과를 담는 파일

## 왜 이 파일이 있는가

레퍼런스를 보고 "이런 느낌이구나" 하고 산문으로만 적어두면, **다음 실행 때 그 산문이 다시 해석된다.**
해석은 매번 조금씩 달라지고, 사용자는 "어제랑 다르게 나왔다"고 느낀다.

그래서 레퍼런스 분석은 **한 번만** 하고, 결과를 이 파일에 숫자로 못 박는다.
렌더러는 이 파일만 읽는다. 산문 기록은 `디자인노트.md`에 따로 남기되, 렌더에는 쓰지 않는다.

```
_레퍼런스/*.png  ──분석(1회)──▶  스타일.json  ──▶  렌더러
                          └────▶  디자인노트.md (사람이 읽는 근거)
```

`스타일.json` = 계정의 생김새 (한 번 정하면 계속 간다)
`spec.json`   = 그날의 내용 (매일 바뀐다)

둘을 섞지 않는다. 이게 어제 만든 카드와 오늘 만든 카드가 같은 계정처럼 보이게 하는 유일한 방법이다.

## 전체 구조

```json
{
  "preset": "photo-dump",

  "canvas": { "size": [1080, 1350], "padding": 88 },

  "palette": {
    "bg": "#15293B", "ink": "#FFFFFF", "accent": "#F5DFA8",
    "sub": "#DCE5EC", "chip": "#2E8FE8"
  },

  "type": {
    "family": "sans",
    "headline_cover": 132, "headline": 84, "body": 40,
    "cta": 46, "info": 28, "label": 30, "script": 60,
    "leading": 1.06, "tracking": -0.035
  },

  "layout": {
    "mode": "photo",
    "band_height": 0.42, "band_side": "top",
    "cover_anchor": "bottom", "body_anchor": "center",
    "align": "left"
  },

  "photo": {
    "legibility": "shadow",
    "veil": 0.22, "veil_color": null, "vignette": true
  },

  "decor": {
    "label": "pill", "chip": "bubble", "insets": 1,
    "stickers": "light", "script": "playfair", "page_number": true
  }
}
```

## 항목별 설명

### preset

`assets/presets/` 안의 파일 이름. 그 프리셋을 먼저 깔고, 이 파일의 나머지 항목이 덮어쓴다.
프리셋만 적고 나머지를 비워두면 프리셋 기본값 그대로 나간다.

### palette

| 키 | 쓰이는 곳 |
|---|---|
| `bg` | 배경 (사진이 덮으면 안 보임). 밴드형에서는 띠 색 |
| `ink` | 헤드라인 |
| `accent` | 라벨 칩, 강조 단어, CTA, 불릿 |
| `sub` | 본문, 계정명, 페이지 번호, 출처 |
| `chip` | 말풍선 칩 배경. 레퍼런스에 포인트색이 따로 있으면 여기 |

대비 기준 — `bg↔ink ≥ 7:1`, `bg↔accent ≥ 4.5:1`, `bg↔sub ≥ 4.5:1`.
**단, `legibility`가 `shadow`면 글자가 사진 위에 뜨므로 이 검사는 참고용이다.**

### type

- `family` — `sans`(고딕) 또는 `serif`(명조). 레퍼런스가 매거진풍이면 `serif`
- 나머지 숫자는 픽셀 단위 폰트 크기
- `leading` — 행간 배수. 레퍼런스가 글자를 빽빽하게 쌓았으면 1.0~1.1, 여유로우면 1.3 이상
- `tracking` — 자간(em). 굵고 큰 헤드라인은 보통 음수(-0.02 ~ -0.05)

### layout

| `mode` | 뜻 |
|---|---|
| `photo` | 사진이 화면을 꽉 채우고 그 위에 글자를 얹는다 |
| `band` | 한쪽에 단색 띠를 깔고 **글자는 전부 띠 안에**, 사진은 나머지에 손대지 않고 넣는다 |
| `solid` | 사진 없이 배경색 + 글자만 |

- `band_height` — 띠가 차지하는 비율 (0~1). `band` 모드에서만
- `band_side` — `top` / `bottom`
- `cover_anchor` / `body_anchor` — 글자 덩어리를 `top` / `center` / `bottom` 중 어디에 붙일지
- `align` — `left` / `center`

### photo

| `legibility` | 뜻 |
|---|---|
| `shadow` | **글자에 그림자를 넣어** 읽히게 한다. 사진을 거의 안 덮으므로 색이 산다 |
| `veil` | 사진 위에 막을 씌워 읽히게 한다. 글자 그림자는 안 넣는다 |

- `veil` — 막 농도 0~1. `shadow`면 0.15~0.35, `veil`이면 0.45~0.65가 보통
- `veil_color` — 비우면 `palette.bg`를 쓴다. **검정보다 배경색 계열이 사진 색을 살린다**
- `vignette` — 위아래 옅은 그라데이션. 계정명·페이지 번호가 밝은 사진에 묻히는 걸 막는다

> `legibility` 판단이 이 파일에서 제일 자주 틀리는 항목이다.
> 레퍼런스 사진이 **밝고 쨍한데 흰 글자가 잘 읽히면** 그건 `shadow`다.
> 사진이 전체적으로 어둡게 눌려 있으면 `veil`이다. 헷갈리면 사진의 밝은 쪽 구석을 보라.

### decor

| 키 | 값 | 뜻 |
|---|---|---|
| `label` | `pill` / `none` | 좌상단 라벨 칩 |
| `chip` | `bubble` / `pill` / `none` | 말풍선(꼬리 있음) / 그냥 알약 / 없음 |
| `insets` | 정수 | 표지에 넣을 폴라로이드 최대 개수. `0`이면 안 넣는다 |
| `stickers` | `none` / `light` / `rich` | `light`는 2개까지, `rich`는 5개까지 |
| `script` | `playfair` / `none` | 이탤릭 스크립트 한 줄. **한글 글리프가 없어 숫자·영문만 들어간다** |
| `page_number` | 참/거짓 | 우하단 `1 / 5` |

> **장식은 신뢰도와 맞바꾸는 것이다.**
> 라이프스타일 계정이면 `rich`가 어울리지만, 뉴스·정보 계정에서 스티커를 뿌리면
> 정보의 무게가 가벼워진다. 레퍼런스가 화려해도 **계정 목적이 정보 전달이면 `light` 이하로 내린다.**
> 설정 파일의 목적(②번 문항)이 `팔로워 확보`·`전문성 각인`이면 `light`,
> `가게 홍보`·`주변에 도움`이면 `rich`까지 허용한다.

## spec.json과의 관계

`spec.json`은 **그날의 내용만** 담는다. 스타일 값을 넣지 않는다.

```json
{
  "output_dir": ".",
  "brand": "@myaccount",
  "cards": [
    { "type": "cover", "filename": "01.png", "bg_image": "./bg/bg_00.jpeg",
      "label": "9월 1일 시행", "headline": "교통비 할인\n39세까지\n올라갑니다",
      "accent_words": ["39세까지"], "script": "(2026. 09. 01)",
      "chip": {"text": "서울시민이면 자동 적용", "emoji": "💳"},
      "insets": [{"image": "./bg/bg_01.jpeg", "label": "K-패스", "x": 68, "y": 10, "w": 23, "rot": 4}],
      "stickers": [{"emoji": "✨", "x": 13, "y": 32, "size": 46, "rot": -12}] }
  ]
}
```

카드 하나에만 예외를 주고 싶으면 그 카드에 `veil`, `veil_color` 같은 키를 직접 적는다.
**우선순위 — 프리셋 < 스타일.json < spec.json의 카드별 값.**

간판·글씨가 많은 사진은 카드별로 `veil`을 0.1쯤 올리는 게 정상이다. 스타일 전체를 건드리지 않는다.
