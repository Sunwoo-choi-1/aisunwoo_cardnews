# 이모지 출처

이 폴더의 SVG는 **Twemoji** (Twitter/X 오픈소스 이모지)입니다.

- 그래픽 라이선스: CC-BY 4.0 — https://creativecommons.org/licenses/by/4.0/
- 원본: https://github.com/jdecked/twemoji

## 왜 시스템 이모지를 안 쓰는가

OS마다 이모지 그림이 다릅니다. Windows는 Segoe UI Emoji, macOS는 Apple Color Emoji,
리눅스는 Noto Color Emoji를 쓰고, 아예 없는 환경도 있습니다.
스킬을 여러 사람이 나눠 쓸 때 **같은 spec으로 다른 그림이 나오면 안 되므로**
SVG를 스킬 안에 넣어 어디서나 같게 만듭니다.

`index.json`이 이모지 문자 → 파일명(코드포인트) 대응표입니다.
여기 없는 이모지를 쓰면 시스템 이모지 폰트로 떨어지고, 그것도 없으면 스티커가 생략됩니다.

## 이모지 추가하기

    python3 - <<'PY'
    import json, urllib.request
    ch, code = "🚀", "1f680"          # 코드포인트는 소문자 16진수
    d = urllib.request.urlopen(
        f"https://cdnjs.cloudflare.com/ajax/libs/twemoji/14.0.2/svg/{code}.svg").read()
    open(f"assets/emoji/{code}.svg","wb").write(d)
    idx = json.load(open("assets/emoji/index.json", encoding="utf-8"))
    idx[ch] = code
    json.dump(idx, open("assets/emoji/index.json","w"), ensure_ascii=False, indent=1)
    PY

## 낱개 SVG가 없는 이유

스킬 업로더가 `.svg`를 "스킬 파일이 아님"으로 걸러내기 때문에, 낱개 파일은
설치 과정에서 사라집니다. 그래서 같은 그림을 `assets/emoji-svg.json` 한 파일에
담아 배포합니다. `cardgen.py`는 낱개 파일이 있으면 그것을, 없으면 JSON을 읽습니다.
