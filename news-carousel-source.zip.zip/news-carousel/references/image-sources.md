# 배경 이미지 (Pexels)

## API 키

- 발급: https://www.pexels.com/api/ — 무료, 가입 후 즉시 발급
- 무료 티어: 시간당 200회 / 월 20,000회. 하루 5장이면 여유롭다
- 환경변수 `PEXELS_API_KEY`로 넣는다. **설정 파일이나 코드에 키를 적지 않는다.**

```bash
# Windows
setx PEXELS_API_KEY "발급받은키"
# macOS / Linux
echo 'export PEXELS_API_KEY="발급받은키"' >> ~/.zshrc
```

## 실행

```bash
python3 scripts/fetch_pexels.py bg "query1" "query2" "query3" "query4" "query5"

# 후보를 눈으로 보고 고르고 싶을 때
python3 scripts/fetch_pexels.py --list "query"
```

검색어 하나당 1장씩, 순서대로 `bg_00.jpeg` … 로 저장된다. 같은 사진이 두 번 쓰이지 않게 중복을 건너뛴다. `bg/credits.json`에 작가명·출처 URL이 남는다.

## 검색어는 영문으로

한글 검색은 결과가 거의 안 나온다. **오늘 소재의 핵심 명사를 영어 일반명사로 바꾼다.** 고유명사는 빼는 편이 낫다 — Pexels에 지역명으로 태깅된 사진은 많지 않다.

| 소재 유형 | 검색어 예시 |
|---|---|
| 가격 · 물가 | `grocery price tag` `shopping receipt` `market stall` |
| 교통 · 이동 | `airport departure` `subway platform` `highway traffic` `ferry terminal` |
| 부동산 · 주거 | `apartment building` `house keys` `moving boxes home` `city skyline` |
| 상권 · 자영업 | `small shop owner` `cafe interior` `open sign storefront` |
| 정책 · 행정 | `government building` `documents desk` `meeting table` |
| 투자 · 금융 | `stock chart screen` `calculator finance` `bank interior` |
| IT · 업계 | `server room` `laptop code` `office team meeting` |
| 자연 · 날씨 | `stormy sea` `sunset ocean` `foggy mountain` `heavy rain city` |
| 육아 · 생활 | `family kitchen` `playground children` `home living room` |

한 세트에 **같은 계열 검색어**를 쓴다. 1번은 `airport departure`, 3번은 `office desk`처럼 섞으면 시리즈로 안 보인다.

## 요청 파라미터 (스크립트에 고정됨)

```
orientation=portrait   # 4:5 캔버스용. landscape는 잘리며 구도가 망가진다
size=large
per_page=15            # 후보를 넉넉히 받아 고른다
```

## 컷 선별 기준

**고를 것**
- 텍스트가 얹힐 **여백**이 있는 컷 — 하늘, 물, 벽면, 안개, 단색 배경
- 피사체가 한쪽으로 치우쳐 반대편이 비어 있는 구도
- 세트 전체가 같은 색온도·채도로 묶이는 조합

**버릴 것**
- 인물 얼굴이 크게 잡힌 컷 — 기사와 무관한 인물이 당사자로 오인된다
- 화면 전체가 디테일로 꽉 찬 컷 — 오버레이를 올려도 안 읽힌다
- 특정 국가·도시로 읽히는 랜드마크 — 소재와 다른 곳이면 이질감이 생긴다
- 외국 간판·문자가 크게 보이는 컷

**중요** — 사진은 분위기용이지 증거 사진이 아니다. 기사에 나온 실제 장소인 것처럼 오해될 컷은 쓰지 않는다.

## 가독성

`spec.json`의 `overlay`로 조절한다.

| 사진 | overlay |
|---|---|
| 어둡고 단순 | 0.35 |
| 보통 | 0.45 |
| 밝거나 복잡 | 0.55 |
| 1번 카드 (헤드라인이 가장 큼) | 0.5 이상 |

0.6으로도 안 읽히면 **그 사진을 버린다.** 더 올리면 사진을 쓰는 의미가 없다.

## 크레딧

`캡션.md` 하단에 넣는다.

```markdown
## 이미지 크레딧
- Photo by Jane Doe on Pexels — https://www.pexels.com/photo/...
```

Pexels 라이선스는 상업적 사용·수정이 자유롭고 출처 표기가 의무는 아니다. 다만 **뉴스 큐레이션 계정은 표기하는 편이 신뢰도에 유리하다.**

## 실패 처리

검색어를 **3회까지** 바꿔본다. 그래도 없으면 `bg_image`를 빼고 팔레트 단색 + 타이포 중심으로 간다. 억지로 안 맞는 사진을 쓰는 것보다 낫다.

`PEXELS_API_KEY`가 없어도 단색 카드로 전체 워크플로우는 돈다. 키가 없다고 중단하지 않는다.
