#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""한글 폰트를 찾는다. render_cards.py와 doctor.py가 함께 쓴다.

단독 실행하면 찾은 폰트를 출력한다:
    python3 fontfind.py
"""

import glob
import os
import subprocess
import sys

# 1순위 — 정확히 아는 경로
KNOWN = {
    "bold": [
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansKR-Bold.otf",
        "/usr/share/fonts/truetype/nanum/NanumGothicBold.ttf",
        "C:/Windows/Fonts/malgunbd.ttf",
        "C:/Windows/Fonts/NanumGothicBold.ttf",
        "/System/Library/Fonts/AppleSDGothicNeo.ttc",
        "/Library/Fonts/AppleGothic.ttf",
    ],
    "regular": [
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Medium.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansKR-Regular.otf",
        "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
        "C:/Windows/Fonts/malgun.ttf",
        "C:/Windows/Fonts/NanumGothic.ttf",
        "/System/Library/Fonts/AppleSDGothicNeo.ttc",
        "/Library/Fonts/AppleGothic.ttf",
    ],
}

# 2순위 — 폰트 폴더를 훑을 때 이름에 이게 들어 있으면 한글 폰트로 본다
NAME_HINTS = ("notosanscjk", "notosanskr", "nanum", "malgun", "applesdgothic",
              "applegothic", "pretendard", "spoqa", "gothic", "batang", "gulim",
              "sourcehansans", "notoserifcjk")
BOLD_HINTS = ("bold", "bd", "black", "heavy", "semibold")

FONT_DIRS = [
    "/usr/share/fonts", "/usr/local/share/fonts",
    os.path.expanduser("~/.fonts"), os.path.expanduser("~/.local/share/fonts"),
    "C:/Windows/Fonts", os.path.expanduser("~/AppData/Local/Microsoft/Windows/Fonts"),
    "/System/Library/Fonts", "/Library/Fonts", os.path.expanduser("~/Library/Fonts"),
]


def _scan(weight):
    hits = []
    for d in FONT_DIRS:
        if not os.path.isdir(d):
            continue
        for ext in ("ttf", "otf", "ttc", "otc"):
            for p in glob.glob(os.path.join(d, "**", f"*.{ext}"), recursive=True):
                name = os.path.basename(p).lower()
                if not any(h in name for h in NAME_HINTS):
                    continue
                is_bold = any(h in name for h in BOLD_HINTS)
                if (weight == "bold") == is_bold:
                    hits.append(p)
    return sorted(hits, key=len)


def _fc_match(weight):
    """fontconfig이 있으면 물어본다 (리눅스·일부 macOS)."""
    try:
        q = "sans-serif:lang=ko"
        if weight == "bold":
            q += ":weight=bold"
        out = subprocess.run(["fc-match", "-f", "%{file}", q],
                             capture_output=True, text=True, timeout=5)
        p = out.stdout.strip()
        return p if p and os.path.exists(p) else None
    except Exception:
        return None


def cjk_index(path):
    """ttc 묶음 안에서 한국어 폰트의 인덱스. 못 찾으면 0."""
    if not path.lower().endswith((".ttc", ".otc")):
        return 0
    try:
        from PIL import ImageFont
    except ImportError:
        return 0
    for i in range(10):
        try:
            f = ImageFont.truetype(path, 20, index=i)
            name = " ".join(str(x) for x in (f.getname() or ()))
            if "KR" in name or "Korean" in name or "Kore" in name:
                return i
        except Exception:
            break
    return 0


def find(weight="bold"):
    """(경로, ttc 인덱스) 또는 (None, 0)."""
    for p in KNOWN[weight]:
        if os.path.exists(p):
            return p, cjk_index(p)
    for p in _scan(weight):
        return p, cjk_index(p)
    p = _fc_match(weight)
    if p:
        return p, cjk_index(p)
    # 굵기를 못 찾으면 반대 굵기라도 쓴다 (□□□보다 낫다)
    other = "regular" if weight == "bold" else "bold"
    for p in KNOWN[other]:
        if os.path.exists(p):
            return p, cjk_index(p)
    for p in _scan(other):
        return p, cjk_index(p)
    return None, 0


INSTALL_HINT = """한글 폰트를 찾지 못했습니다. 폰트 없이 렌더하면 글자가 전부 □□□로 나옵니다.

  Ubuntu / Debian : sudo apt-get install -y fonts-noto-cjk
  Fedora / RHEL   : sudo dnf install -y google-noto-sans-cjk-fonts
  Alpine          : apk add font-noto-cjk
  macOS           : 기본 탑재(Apple SD Gothic Neo). 못 찾으면
                    brew install --cask font-noto-sans-cjk-kr
  Windows         : 기본 탑재(맑은 고딕). 못 찾으면 나눔고딕을 설치하세요
  공통 대안        : 나눔고딕 .ttf를 내려받아 ~/.fonts/ 에 넣으세요
                    https://hangeul.naver.com/font"""


if __name__ == "__main__":
    ok = True
    for w in ("bold", "regular"):
        p, i = find(w)
        if p:
            print(f"{w:8s} {p}" + (f"  (index {i})" if i else ""))
        else:
            print(f"{w:8s} 없음")
            ok = False
    if not ok:
        print("\n" + INSTALL_HINT)
    sys.exit(0 if ok else 1)
