#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""카드뉴스 작업 폴더 구조를 갖춘다.

사용자가 이미 폴더를 만들어 뒀으면 **그 폴더를 그대로 쓴다.** 안에 없는 것만 채운다.
폴더가 없을 때만 새로 만든다.

사용법:
    python3 setup_workspace.py <경로> [YYYY-MM-DD]

경로를 어떻게 해석하는가 — 이것이 이 스크립트의 핵심이다.

| 준 경로 | 결과 |
|---|---|
| 이미 카드뉴스 작업 폴더 (설정 파일·레퍼런스 폴더가 있거나 이름에 '카드뉴스') | 그 폴더를 루트로 쓴다 |
| 비어 있거나 관계없는 폴더 (바탕화면·문서 등) | 그 아래 `카드뉴스/` 를 만든다 |

`카드뉴스자동화` 같은 폴더를 사용자가 만들어 뒀는데 그 안에 또 `카드뉴스/` 를
만들면 사용자는 자기가 만든 폴더가 무시당했다고 느낀다. 그래서 이렇게 판정한다.

레퍼런스 폴더 이름은 이미 있는 것을 따른다. `레퍼런스`(언더바 없음)를 만들어 뒀으면
그것을 쓰고, 없을 때만 `_레퍼런스`를 만든다. 같은 폴더를 두 개로 만들지 않는다.

출력: JSON 한 줄 (root / today / bg / config / reference / my_photos / my_photo_count)
      이미 있는 것은 건드리지 않고 경로만 돌려준다. 덮어쓰지 않는다.
"""

import datetime
import json
import os
import sys

import project

PROJECT_DIR_NAME = project.PROJECT_DIR_NAME
CONFIG_NAME = project.CONFIG_NAME


def resolve_root(base):
    """준 경로를 루트로 쓸지, 그 아래에 만들지 정한다. (루트경로, 새로만들었나)"""
    base = os.path.abspath(os.path.expanduser(base))

    if os.path.basename(base) == PROJECT_DIR_NAME:
        return base, False
    if project.root_evidence(base):
        return base, False          # 사용자가 만들어 둔 작업 폴더다
    return os.path.join(base, PROJECT_DIR_NAME), True


def build(base, today=None):
    root, created_subdir = resolve_root(base)
    os.makedirs(root, exist_ok=True)

    today = today or datetime.date.today().isoformat()
    day = os.path.join(root, today)
    bg = os.path.join(day, "bg")

    ref = project.reference_dir(root, create=True)
    mine = project.myphoto_dir(root, create=True)

    for d in (day, bg):
        os.makedirs(d, exist_ok=True)

    return {
        "root": root,
        "created_subfolder": created_subdir,
        "evidence": project.root_evidence(root),
        "today": day,
        "bg": bg,
        "config": os.path.join(root, CONFIG_NAME),
        "config_exists": os.path.isfile(os.path.join(root, CONFIG_NAME)),
        "reference": ref,
        "reference_count": project.count_images(ref),
        "my_photos": mine,
        "my_photo_count": project.count_images(mine),
    }


def main(argv):
    if len(argv) < 2:
        print(__doc__.strip(), file=sys.stderr)
        return 2
    info = build(argv[1], argv[2] if len(argv) > 2 else None)
    print(json.dumps(info, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
