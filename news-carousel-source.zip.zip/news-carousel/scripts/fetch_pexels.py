#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pexels에서 세로형 무료 이미지를 검색해 카드뉴스 배경으로 내려받는다.

사용법:
    python3 fetch_pexels.py <출력폴더> "query1" "query2" ... "query5"

API 키는 두 곳에서 찾는다 (앞의 것이 이긴다):
    1) 환경변수 PEXELS_API_KEY
    2) 카드뉴스-설정.md 의 `- API 키:` 줄
       → 사용자가 채팅에 키를 붙여넣으면 설정 파일에 적어두기만 하면 된다.
          환경변수를 따로 등록할 필요가 없다.

    # 후보만 보고 직접 고르고 싶을 때
    python3 fetch_pexels.py --list "coastline sunset"

동작:
    - 검색어 하나당 이미지 1장씩, 순서대로 bg_00.jpeg, bg_01.jpeg ... 로 저장
    - 같은 사진이 두 번 쓰이지 않도록 photo id를 기록해 중복을 건너뛴다
    - bg/credits.json 에 작가명·출처 URL을 남긴다 (캡션에 그대로 사용)

주의:
    - 검색어는 반드시 영문. 한글은 결과 품질이 급락한다.
    - orientation=portrait 고정. 4:5 캔버스에 맞추기 위함이다.
"""

import json
import os
import sys
import urllib.parse
import urllib.request

API = "https://api.pexels.com/v1/search"
PER_PAGE = 15
UA = "news-carousel/1.0"


sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pexels_key import resolve as _resolve_key  # noqa: E402


def api_key():
    k, src = _resolve_key()
    if k == "없음":
        sys.exit(
            "설정에 '없음'으로 적혀 있습니다. 사용자가 사진을 쓰지 않기로 한 것입니다.\n"
            "  이 단계를 건너뛰고 색상 카드로 만드세요. 키를 다시 묻지 마세요."
        )
    if not k:
        sys.exit(
            "Pexels API 키를 찾지 못했습니다.\n"
            "  작업 폴더 안이면 어디에 붙여넣어도 찾습니다 —\n"
            "  권장: 카드뉴스-설정.md 의 '- API 키:' 줄\n"
            "  가능: 폴더 안 메모장(.txt), 파일 이름 자체\n"
            "  키 발급: https://www.pexels.com/api/  (무료, 가입 후 즉시)\n"
            "\n"
            "  키 없이도 단색 배경 카드는 만들 수 있습니다. 이 단계를 건너뛰세요."
        )
    print(f"  키 출처: {src}", file=sys.stderr)
    return k


def search(query, key):
    params = urllib.parse.urlencode(
        {"query": query, "orientation": "portrait", "size": "large", "per_page": PER_PAGE}
    )
    req = urllib.request.Request(
        f"{API}?{params}", headers={"Authorization": key, "User-Agent": UA}
    )
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r).get("photos", [])


def download(url, path):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=120) as r, open(path, "wb") as f:
        f.write(r.read())
    return os.path.getsize(path)


def list_mode(query):
    key = api_key()
    photos = search(query, key)
    if not photos:
        print(f"결과 없음: {query}")
        return 1
    print(f"'{query}' 후보 {len(photos)}장\n")
    for i, p in enumerate(photos):
        print(f"[{i:2d}] id={p['id']}  {p['width']}x{p['height']}")
        print(f"     작가: {p['photographer']}")
        print(f"     페이지: {p['url']}")
        print(f"     원본: {p['src']['large2x']}\n")
    return 0


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1

    if argv[1] == "--list":
        if len(argv) < 3:
            print(__doc__)
            return 1
        return list_mode(argv[2])

    outdir = argv[1]
    queries = argv[2:]
    if not queries:
        print(__doc__)
        return 1

    key = api_key()
    os.makedirs(outdir, exist_ok=True)

    used = set()
    credits = []
    failed = []

    for i, q in enumerate(queries):
        try:
            photos = search(q, key)
        except Exception as e:
            print(f"  ! [{i}] '{q}' 검색 실패: {e}", file=sys.stderr)
            failed.append(q)
            continue

        pick = next((p for p in photos if p["id"] not in used), None)
        if pick is None:
            print(f"  ! [{i}] '{q}' 쓸 수 있는 결과 없음 (중복 제외 후 0장)", file=sys.stderr)
            failed.append(q)
            continue

        used.add(pick["id"])
        path = os.path.join(outdir, f"bg_{i:02d}.jpeg")
        try:
            size = download(pick["src"]["large2x"], path)
        except Exception as e:
            print(f"  ! [{i}] '{q}' 다운로드 실패: {e}", file=sys.stderr)
            failed.append(q)
            continue

        credits.append(
            {
                "index": i,
                "file": os.path.basename(path),
                "query": q,
                "photographer": pick["photographer"],
                "photographer_url": pick["photographer_url"],
                "source": pick["url"],
                "credit": f"Photo by {pick['photographer']} on Pexels",
            }
        )
        print(f"  bg_{i:02d}.jpeg  {size // 1024}KB  ({pick['photographer']}) ← {q}")

    with open(os.path.join(outdir, "credits.json"), "w", encoding="utf-8") as f:
        json.dump(credits, f, ensure_ascii=False, indent=2)

    print(f"\n{len(credits)}/{len(queries)}장 저장 · credits.json 생성")
    if failed:
        print(f"실패한 검색어: {', '.join(failed)}", file=sys.stderr)
        print("검색어를 바꿔 다시 시도하세요. 3회 실패 시 단색 배경으로 전환합니다.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
