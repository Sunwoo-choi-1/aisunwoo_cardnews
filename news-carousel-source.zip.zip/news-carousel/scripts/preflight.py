#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""카드뉴스를 만들 준비가 됐는지 검사한다.

준비 여부는 폴더 상태로 정해진다. 이 스크립트의 종료 코드가 그 판정이다.
판단을 사람 눈에 맡기지 않는 것이 이 스크립트가 있는 이유다.

사용법:
    python3 preflight.py <프로젝트루트>
    python3 preflight.py              # 루트를 알아서 찾는다

출력: JSON 한 줄
    root            검사한 폴더
    ready           준비 완료 여부 (True면 바로 제작 가능)
    missing         빠진 것들의 목록 (사용자에게 그대로 안내한다)
    background      "Pexels" | "색상만" | "미정"
    key_source      키를 찾은 자리 (설정 파일 · 파일 이름 · 환경변수 …)
    brand           계정명 (선택 항목. 없으면 "" — 카드에 계정명 줄을 넣지 않는다)
    reference_dir   레퍼런스 폴더 경로 (이름이 무엇이든 찾아낸다)
    reference_count 레퍼런스 폴더 안의 이미지 장수
    my_photo_count  내사진 폴더 안의 이미지 장수
    style_exists    스타일.json 유무
    config_exists   카드뉴스-설정.md 유무
    topic           설정 파일의 `## 주제`가 채워져 있는지

필수는 배경 방식 하나뿐이다. 계정명·참고 이미지·설정 파일은 있으면 쓰고 없으면 넘어간다.
**키를 폴더 안 아무 곳에나 붙여넣어도 찾는다.** 설정 파일이 없어도 키만 있으면 준비된 것이다.

종료 코드
    0  준비 완료
    3  준비 안 됨 (설정 안내가 필요하다)
    2  루트를 못 찾음
"""

import json
import os
import re
import sys

import project

CONFIG_NAME = project.CONFIG_NAME
PLACEHOLDER = project.PLACEHOLDER


def field(text, *labels):
    """'- 라벨: `값`' 형태에서 값을 뽑는다. 못 찾으면 ''."""
    for line in text.splitlines():
        if not any(lb in line for lb in labels):
            continue
        _, sep, raw = line.partition(":")
        if not sep:
            continue
        raw = raw.strip().strip("`\"' ")
        raw = raw.split("←")[0].split("#")[0].strip().strip("`\"' ")
        if raw:
            return raw
    return ""


def has_topic(text):
    """`## 주제` 아래에 사용자가 채운 내용이 있는지."""
    m = re.search(r"^##\s*주제\s*$(.*?)(?=^##\s|\Z)", text, re.M | re.S)
    if not m:
        return False
    body = m.group(1)
    for line in body.splitlines():
        line = line.strip().lstrip("-*").strip()
        if not line:
            continue
        _, sep, val = line.partition(":")
        val = (val if sep else line).strip().strip("`\"' ")
        if val and not PLACEHOLDER.search(val):
            return True
    return False


def main(argv):
    root = argv[1] if len(argv) > 1 else project.find_root()
    if not root:
        print(json.dumps({"root": None, "ready": False,
                          "missing": ["작업 폴더"]}, ensure_ascii=False))
        return 2

    root = os.path.abspath(os.path.expanduser(root))
    cfg_path = os.path.join(root, CONFIG_NAME)
    ref = project.reference_dir(root)
    mine = project.myphoto_dir(root)

    info = {
        "root": root,
        "ready": False,
        "missing": [],
        "brand": "",
        "background": "미정",
        "key_source": None,
        "reference_dir": ref,
        "reference_count": project.count_images(ref),
        "my_photo_count": project.count_images(mine),
        "style_exists": os.path.isfile(os.path.join(root, "스타일.json")),
        "config_exists": os.path.isfile(cfg_path),
        "topic": False,
    }

    if info["config_exists"]:
        with open(cfg_path, encoding="utf-8") as f:
            text = f.read()
        brand = field(text, "계정명", "brand")
        if brand and not PLACEHOLDER.search(brand):
            info["brand"] = brand
        info["topic"] = has_topic(text)

    # ── 배경 방식 — 폴더 전체에서 키를 찾는다 ─────────────────
    key, src = project.scan_key(root)
    if key == "없음":
        info["background"] = "색상만"
        info["key_source"] = src
    elif key:
        info["background"] = "Pexels"
        info["key_source"] = src
    else:
        info["missing"].append("Pexels API 키 (또는 '없음')")

    info["ready"] = not info["missing"]
    print(json.dumps(info, ensure_ascii=False))
    return 0 if info["ready"] else 3


if __name__ == "__main__":
    sys.exit(main(sys.argv))
