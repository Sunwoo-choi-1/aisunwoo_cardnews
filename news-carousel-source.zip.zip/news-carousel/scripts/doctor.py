#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
실행 환경을 점검한다. 카드뉴스를 만들기 전에 한 번 돌린다.

사용법:
    python3 doctor.py

종료 코드
    0  전부 정상
    1  카드를 만들 수 없음 (Python / Pillow / 한글 폰트 중 하나가 없음)
    2  만들 수는 있지만 제한이 있음 (Pexels 키가 없거나, 렌더러가 폴백으로 내려감)

렌더러는 두 가지다. 이 스크립트가 어느 쪽을 쓸지 정해 준다.
    cardgen.py       Chromium 필요. 레퍼런스 재현용 (그림자·밴드·명조·장식)
    render_cards.py  Pillow만 필요. 어디서나 도는 폴백. 장식은 빠진다
"""

import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

OK, WARN, FAIL = "정상", "제한", "없음"
rows = []
blocking = False
limited = False


def add(name, state, detail):
    rows.append((name, state, detail))


# ── Python ────────────────────────────────────────────────
v = sys.version_info
if v >= (3, 8):
    add("Python", OK, f"{v.major}.{v.minor}.{v.micro}")
else:
    add("Python", FAIL, f"{v.major}.{v.minor} — 3.8 이상이 필요합니다")
    blocking = True

# ── Pillow ────────────────────────────────────────────────
try:
    import PIL
    add("Pillow", OK, PIL.__version__)
except ImportError:
    add("Pillow", FAIL, "pip install pillow")
    blocking = True

# ── 한글 폰트 ──────────────────────────────────────────────
try:
    import fontfind
    bp, bi = fontfind.find("bold")
    rp, ri = fontfind.find("regular")
    if bp and rp:
        same = os.path.basename(bp) == os.path.basename(rp)
        detail = os.path.basename(bp) + ("" if same else f" / {os.path.basename(rp)}")
        if same:
            detail += " (굵기 구분 없음 — 헤드라인 대비가 약할 수 있습니다)"
        add("한글 폰트", OK, detail)
    else:
        add("한글 폰트", FAIL, "찾지 못함")
        blocking = True
except ImportError:
    add("한글 폰트", FAIL, "fontfind.py를 찾을 수 없습니다")
    blocking = True

# ── 렌더러 ────────────────────────────────────────────────
renderer = "render_cards.py"
try:
    import cardgen
    _ok, _why = cardgen.capability()
    if _ok:
        renderer = "cardgen.py"
        add("렌더러", OK, "cardgen.py — 레퍼런스 재현 가능 (그림자·밴드·명조·장식)")
    else:
        add("렌더러", WARN, f"cardgen.py 사용 불가({_why}) → render_cards.py로 진행")
        limited = True
except Exception as e:
    add("렌더러", WARN, f"cardgen.py 불러오기 실패({str(e)[:40]}) → render_cards.py로 진행")
    limited = True

# ── 이모지 ────────────────────────────────────────────────
_A = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "assets")
_emoji_idx = os.path.join(_A, "emoji", "index.json")
_emoji_svg = os.path.join(_A, "emoji-svg.json")
if os.path.exists(_emoji_idx) and os.path.exists(_emoji_svg):
    import json as _json
    _n = len(_json.load(open(_emoji_svg, encoding="utf-8")))
    add("이모지", OK, f"스킬에 포함된 Twemoji {_n}종 — OS와 무관하게 같은 그림")
else:
    add("이모지", WARN, "assets/emoji-svg.json 없음 — 스티커는 생략됩니다")

# ── Pexels ────────────────────────────────────────────────
try:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from pexels_key import resolve as _resolve_key, find_config as _find_config

    _key, _src = _resolve_key()
except Exception:
    _key, _src, _find_config = None, None, lambda: None

if _key:
    add("Pexels 키", OK,
        "환경변수 등록됨" if _src == "환경변수" else f"설정 파일에서 읽음 ({os.path.basename(_src)})")
else:
    _cfg = _find_config()
    _hint = "설정 파일에 키를 붙여넣으세요" if _cfg else "없음"
    add("Pexels 키", WARN, f"{_hint} — 지금은 배경 사진 없이 단색 카드로 만듭니다")
    limited = True

# ── 네트워크 (선택) ─────────────────────────────────────────
if shutil.which("curl"):
    try:
        r = subprocess.run(["curl", "-s", "-o", os.devnull, "-w", "%{http_code}",
                            "-m", "6", "https://api.pexels.com/"],
                           capture_output=True, text=True, timeout=10)
        add("네트워크", OK if r.stdout.strip() else WARN,
            "Pexels 접속 가능" if r.stdout.strip() else "확인 실패 — 오프라인일 수 있습니다")
    except Exception:
        add("네트워크", WARN, "확인 실패")
else:
    add("네트워크", WARN, "curl 없음 — 건너뜀")

# ── 출력 ──────────────────────────────────────────────────
import unicodedata


def dw(s):
    """한글은 두 칸을 차지한다."""
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in s)


def padded(s, width):
    return s + " " * max(0, width - dw(s))


nw = max(dw(n) for n, _, _ in rows)
sw = max(dw(s) for _, s, _ in rows)
print("\n환경 점검\n" + "─" * 60)
for name, state, detail in rows:
    print(f"  {padded(name, nw)}   {padded(state, sw)}   {detail}")
print("─" * 60)

if blocking:
    print("\n카드를 만들 수 없습니다. 아래를 먼저 해결하세요.\n")
    for name, state, detail in rows:
        if state == FAIL:
            if name == "Pillow":
                print("  Pillow 설치")
                print("    pip install pillow")
                print("    (권한 오류가 나면)  pip install --user pillow")
                print("    (외부 관리 환경이면) pip install --break-system-packages pillow\n")
            elif name == "한글 폰트":
                try:
                    import fontfind
                    print("  " + fontfind.INSTALL_HINT.replace("\n", "\n  ") + "\n")
                except ImportError:
                    print("  fontfind.py가 scripts/ 폴더에 있어야 합니다\n")
            elif name == "Python":
                print("  Python 3.8 이상을 설치하세요: https://www.python.org/downloads/\n")
    sys.exit(1)

if limited:
    print(f"\n렌더러 → {renderer}")
    if renderer != "cardgen.py":
        print("  이 환경에는 Chromium이 없어 폴백 렌더러로 그립니다.")
        print("  말풍선·폴라로이드·스티커·명조 헤드라인·컬러밴드는 빠지고,")
        print("  사진 위 글자는 어두운 막으로 읽히게 합니다. 카드 제작 자체는 멈추지 않습니다.")
        print("  레퍼런스대로 뽑고 싶으면:  pip install playwright && playwright install chromium\n")
    print("\n카드는 만들 수 있습니다. 다만 이대로 진행하지 마세요.")
    print("  → SKILL.md 0-2b 로 가서 설정 파일을 만들어 안내하고 이번 실행을 마치세요.")
    print("     대화창에서 키를 묻지 않습니다. 묻지 않고 단색 카드를 완성해")
    print("     내미는 것도 가장 흔한 실패입니다.")
    print("\n  키 넣는 곳 — 작업 폴더 안이면 어디든 찾아냅니다")
    print("  권장    : 카드뉴스-설정.md 의 '- API 키:' 줄")
    print("  가능    : 폴더 안 메모장(.txt), 파일 이름 자체도 인식합니다")
    print("  발급    : https://www.pexels.com/api/  (무료, 가입 후 즉시)")
    print("  사진 없이 : 키 자리에 '없음' 이라고 적으면 색상 카드로 만듭니다")
    print("  내 사진 : '내사진' 폴더에 넣거나 대화창에 끌어다 놓으면 됩니다")
    sys.exit(2)

print(f"\n전부 정상입니다.  렌더러 → {renderer}")
sys.exit(0)
