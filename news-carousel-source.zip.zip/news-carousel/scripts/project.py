#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""프로젝트 폴더를 알아보는 공용 함수들.

사용자가 폴더를 어떻게 만들었든, 키를 어디에 붙여넣었든 찾아내는 것이 목적이다.
초보 사용자는 안내대로 하지 않는다. 설정 파일에 넣으라고 해도 메모장에 붙이고,
파일 이름을 키로 만들고, 폴더 이름을 `카드뉴스자동화`라고 짓는다.
그때마다 "못 찾았습니다"라고 하면 스킬이 쓸모없어진다. 그래서 넓게 찾는다.

다른 스크립트에서 이렇게 쓴다.

    import project
    root = project.find_root()
    ref  = project.reference_dir(root)
    key, src = project.scan_key(root)
"""

import glob
import os
import re

CONFIG_NAME = "카드뉴스-설정.md"

# 레퍼런스 폴더 이름 — 사용자가 언더바를 빼고 만드는 경우가 흔하다.
# 앞에 있는 것을 먼저 찾고, 새로 만들 때는 [0]을 쓴다.
REFERENCE_NAMES = ("_레퍼런스", "레퍼런스", "레퍼런스이미지", "reference", "ref")
MYPHOTO_NAMES = ("내사진", "내 사진", "myphotos", "photos")

PROJECT_DIR_NAME = "카드뉴스"

IMG_EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff", ".heic", ".heif"}

# 키가 들어 있을 만한 텍스트 파일
TEXT_EXT = {".md", ".txt", ".env", ".json", ".cfg", ".ini", ".text", ""}
MAX_TEXT_BYTES = 256 * 1024

# ── Pexels 키 모양 ────────────────────────────────────────────────
# 실제 키는 영숫자 56자다. 서비스가 길이를 바꿀 수 있으니 40~80자로 잡고,
# 대문자·소문자·숫자가 모두 섞여 있을 것을 요구해 일반 단어·해시와 구분한다.
_KEY_SHAPE = re.compile(r"[A-Za-z0-9]{40,80}")
_HINT = re.compile(r"(pexels|api|키|key|토큰|token)", re.IGNORECASE)

# 사용자가 아직 안 채운 자리표시자
PLACEHOLDER = re.compile(
    r"(붙여넣|여기에|발급받은키|your[_ -]?key|환경변수|^@?계정명$|^x+$|^-+$)",
    re.IGNORECASE,
)
# 사진을 안 쓰겠다는 명시적 표현
OPT_OUT = re.compile(r"^(없음|없어요|안\s*씀|안써|사용안함|none|no|skip)$", re.IGNORECASE)


def looks_like_key(s):
    """Pexels API 키로 보이는 문자열인가."""
    if not s or not _KEY_SHAPE.fullmatch(s):
        return False
    return (
        any(c.islower() for c in s)
        and any(c.isupper() for c in s)
        and any(c.isdigit() for c in s)
    )


# ── 폴더 안의 하위 폴더 찾기 ──────────────────────────────────────


def _pick_dir(root, names):
    for n in names:
        p = os.path.join(root, n)
        if os.path.isdir(p):
            return p
    return None


def reference_dir(root, create=False):
    """레퍼런스 폴더 경로. 이름이 무엇이든 찾아낸다.

    create=True 면 없을 때 REFERENCE_NAMES[0] 이름으로 만든다.
    """
    found = _pick_dir(root, REFERENCE_NAMES)
    if found:
        return found
    if create:
        p = os.path.join(root, REFERENCE_NAMES[0])
        os.makedirs(p, exist_ok=True)
        return p
    return None


def myphoto_dir(root, create=False):
    found = _pick_dir(root, MYPHOTO_NAMES)
    if found:
        return found
    if create:
        p = os.path.join(root, MYPHOTO_NAMES[0])
        os.makedirs(p, exist_ok=True)
        return p
    return None


def count_images(d):
    if not d or not os.path.isdir(d):
        return 0
    return sum(
        1 for p in glob.glob(os.path.join(d, "*"))
        if os.path.splitext(p)[1].lower() in IMG_EXT
    )


# ── 이 폴더가 카드뉴스 작업 폴더인가 ──────────────────────────────


def root_evidence(d):
    """카드뉴스 작업 폴더라고 볼 근거들. 강한 것이 앞에 온다. 없으면 빈 리스트."""
    if not d or not os.path.isdir(d):
        return []

    why = []
    if os.path.isfile(os.path.join(d, CONFIG_NAME)):
        why.append("설정 파일")
    if os.path.isfile(os.path.join(d, "스타일.json")):
        why.append("스타일.json")

    base = os.path.basename(os.path.abspath(d))
    if "카드뉴스" in base or "카드 뉴스" in base:
        why.append("폴더 이름")

    ref = reference_dir(d)
    if ref:
        why.append(f"{os.path.basename(ref)} 폴더")

    if _pick_dir(d, MYPHOTO_NAMES):
        why.append("내사진 폴더")

    return why


def find_root(candidates=None, cwd=None):
    """카드뉴스 작업 폴더를 찾는다. 못 찾으면 None.

    근거가 강한 폴더가 이긴다. 설정 파일이 있는 폴더 > 이름·하위폴더로 추정한 폴더.
    """
    best, best_score = None, 0
    for d in candidates or default_candidates(cwd):
        d = os.path.expanduser(d)
        why = root_evidence(d)
        if not why:
            continue
        # 설정 파일이 있으면 확실하다. 나머지는 근거 개수로 판단한다.
        score = 100 if "설정 파일" in why else len(why)
        if score > best_score:
            best, best_score = os.path.abspath(d), score
            if score >= 100:
                break
    return best


def default_candidates(cwd=None):
    """훑어볼 폴더 목록. 앞에 있는 것이 먼저 검사된다.

    1) 현재 폴더와 그 상위 5단계
    2) ~/mnt/*  와 그 한 단계 아래  — 데스크톱에서 연결한 폴더가 붙는 자리
    3) /mnt/user-data/uploads/*
    4) ~/ 바로 아래 한 단계
    """
    out = []

    d = os.path.abspath(cwd or os.getcwd())
    for _ in range(6):
        out.append(d)
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent

    home = os.path.expanduser("~")
    for pattern in (
        os.path.join(home, "mnt", "*"),
        os.path.join(home, "mnt", "*", "*"),
        os.path.join("/mnt", "user-data", "uploads", "*"),
        os.path.join(home, "*"),
    ):
        out.extend(sorted(p for p in glob.glob(pattern) if os.path.isdir(p)))

    seen, uniq = set(), []
    for p in out:
        rp = os.path.realpath(p)
        if rp not in seen:
            seen.add(rp)
            uniq.append(p)
    return uniq


# ── 키 찾기 ───────────────────────────────────────────────────────


def _read_text(path):
    try:
        if os.path.getsize(path) > MAX_TEXT_BYTES:
            return ""
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


def key_from_config_text(text):
    """설정 파일 본문에서 `- API 키:` 줄을 뽑는다. 못 찾으면 None."""
    for line in text.splitlines():
        if "API 키" not in line and "PEXELS_API_KEY" not in line and "api key" not in line.lower():
            continue
        _, sep, raw = line.partition(":")
        if not sep:
            _, sep, raw = line.partition("=")
        if not sep:
            continue
        raw = raw.strip().strip("`\"' ")
        raw = raw.split("←")[0].split("#")[0].split("(")[0].strip().strip("`\"' ")
        if not raw or PLACEHOLDER.search(raw):
            continue
        if OPT_OUT.match(raw):
            return "없음"
        if re.fullmatch(r"[A-Za-z0-9_\-]{20,120}", raw):
            return raw
    return None


def scan_key(root):
    """(키, 출처) 를 돌려준다. 못 찾으면 (None, None).

    키가 '없음'이면 사용자가 사진을 안 쓰겠다고 명시한 것이므로 ("없음", 출처).

    찾는 순서 — 명시적인 것부터
      1) 환경변수 PEXELS_API_KEY
      2) 카드뉴스-설정.md 의 `- API 키:` 줄
      3) 폴더 안 텍스트 파일에서 pexels·api·키 가 같이 있는 줄
      4) 폴더 안 텍스트 파일의 키 모양 문자열
      5) 파일 이름 / 폴더 이름 자체가 키 모양 (영상에서 이렇게 붙여넣는다)
    """
    env = os.environ.get("PEXELS_API_KEY", "").strip()
    if env:
        return env, "환경변수"

    if not root or not os.path.isdir(root):
        return None, None

    # 2) 설정 파일
    cfg = os.path.join(root, CONFIG_NAME)
    if os.path.isfile(cfg):
        k = key_from_config_text(_read_text(cfg))
        if k:
            return k, cfg

    entries = sorted(glob.glob(os.path.join(root, "*")))

    # 3·4) 폴더 안 텍스트 파일
    loose = None
    for p in entries:
        if not os.path.isfile(p):
            continue
        if os.path.splitext(p)[1].lower() not in TEXT_EXT:
            continue
        if os.path.abspath(p) == os.path.abspath(cfg):
            continue
        text = _read_text(p)
        if not text:
            continue
        for line in text.splitlines():
            for m in _KEY_SHAPE.finditer(line):
                if not looks_like_key(m.group()):
                    continue
                if _HINT.search(line):
                    return m.group(), p          # 3) 힌트가 같은 줄에 있다
                loose = loose or (m.group(), p)  # 4) 일단 기억만
    if loose:
        return loose

    # 5) 이름이 키 그 자체
    for p in entries:
        stem = os.path.splitext(os.path.basename(p))[0].strip()
        if looks_like_key(stem):
            return stem, f"{p} (파일 이름)"

    return None, None


if __name__ == "__main__":
    import json
    import sys

    r = sys.argv[1] if len(sys.argv) > 1 else find_root()
    if not r:
        print(json.dumps({"root": None}, ensure_ascii=False))
        sys.exit(1)
    k, src = scan_key(r)
    print(json.dumps({
        "root": r,
        "evidence": root_evidence(r),
        "reference": reference_dir(r),
        "key_found": bool(k and k != "없음"),
        "key_source": src,
    }, ensure_ascii=False))
