#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
레퍼런스 이미지에서 색과 구조를 재서 스타일.json 초안을 만든다.

사용법:
    python3 analyze_reference.py <이미지 또는 폴더>              사람이 읽는 보고서
    python3 analyze_reference.py <...> --json                    팔레트만
    python3 analyze_reference.py <...> --style [> 스타일.json]   스타일.json 초안

측정하는 것 — 색, 전체 밝기, 가로 띠(밴드) 유무, 단색 여부.
측정 못 하는 것 — 헤드라인 크기 비율, 글자 정렬, 장식 종류.
그건 이미지를 직접 열어 references/reference-intake.md 체크리스트로 채운다.
**이 스크립트의 preset 추정은 초안이다. 눈으로 확인하고 고쳐야 한다.**
"""

import json
import os
import sys
from collections import Counter

try:
    from PIL import Image
except ImportError:
    sys.exit("Pillow가 없습니다:  pip install pillow")

EXTS = (".png", ".jpg", ".jpeg", ".webp", ".bmp")


def rgb2hex(t):
    return "#{:02X}{:02X}{:02X}".format(*t)


def lum(rgb):
    def ch(c):
        c /= 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = lum(a), lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def saturation(rgb):
    mx, mn = max(rgb), min(rgb)
    return 0 if mx == 0 else (mx - mn) / mx


def rowstats(im, bands=64):
    """가로로 잘라 각 띠의 '단색 점유율'을 잰다.

    색 흩어짐(분산)으로 띠를 찾으면 **띠 안에 글자가 있을 때 실패한다.**
    글자가 분산을 크게 올리기 때문이다. 그래서 분산 대신
    '그 줄에서 대표색과 비슷한 픽셀이 몇 %인가'를 본다.
    단색 띠는 글자가 있어도 대표색 점유율이 높게 유지된다.
    """
    im = im.convert("RGB")
    w, h = im.size
    step = max(1, h // bands)
    out = []
    for y in range(0, h - step + 1, step):
        strip = im.crop((0, y, w, y + step))
        strip.thumbnail((48, 48))
        px = list((getattr(strip, "get_flattened_data", None) or strip.getdata)())
        n = len(px)
        # 대표색 = 양자화 후 최빈색
        q = strip.quantize(colors=4, method=Image.MEDIANCUT).convert("RGB")
        qp = list((getattr(q, "get_flattened_data", None) or q.getdata)())
        rep = Counter(qp).most_common(1)[0][0]
        near = sum(1 for c in px
                   if abs(c[0]-rep[0]) + abs(c[1]-rep[1]) + abs(c[2]-rep[2]) < 90)
        mean = tuple(sum(c[i] for c in px) / n for i in range(3))
        out.append({"y": y / h, "mean": mean, "rep": rep, "cover": near / n})
    return out


def measure(paths):
    """레이아웃 단서를 숫자로 뽑는다.

    막 유무의 핵심 지표는 평균 밝기가 아니라 **밝은 쪽 끝(p98)** 이다.
    사진에 막을 씌우면 밝은 부분이 먼저 눌린다. 평균만 보면
    '원래 어두운 사진'과 '막을 씌운 사진'을 구분하지 못한다.
    """
    im = Image.open(paths[0]).convert("RGB")
    im.thumbnail((700, 900))
    rows = rowstats(im)
    cov = [r["cover"] for r in rows]
    mean_cov = sum(cov) / len(cov)

    small = im.copy()
    small.thumbnail((260, 260))
    _sd = (getattr(small, "get_flattened_data", None) or small.getdata)()
    L = sorted(lum(c) for c in _sd)
    n = len(L)
    p50, p90, p98 = L[n // 2], L[int(n * 0.90)], L[int(n * 0.98)]

    # 단색: 전 구간이 대표색으로 덮여 있다
    solid = mean_cov >= 0.74

    # 띠 찾기 — 단색 띠의 결정적 증거는 두 가지다.
    #   ① 띠 안에서 줄마다 대표색이 **똑같다** (글자가 있어도 안 변한다)
    #   ② 띠가 끝나는 자리에 색이 **뚝 끊긴다** (사진 안에서는 이렇게 안 끊긴다)
    # 점유율이나 분산만 보면 밝고 평평한 벽·하늘을 띠로 착각한다.
    def dist(x, y):
        return abs(x[0]-y[0]) + abs(x[1]-y[1]) + abs(x[2]-y[2])

    means = [r["mean"] for r in rows]
    jumps = [dist(means[i], means[i - 1]) for i in range(1, len(means))]
    med_jump = sorted(jumps)[len(jumps) // 2] or 1.0

    best = None
    if not solid:
        for side in ("top", "bottom"):
            for frac in [i / 100 for i in range(20, 61, 2)]:
                k = max(3, int(len(rows) * frac))
                if k >= len(rows) - 3:
                    continue
                sub = rows[:k] if side == "top" else rows[-k:]
                base = Counter(r["rep"] for r in sub).most_common(1)[0][0]
                cons = sum(1 for r in sub if dist(r["rep"], base) < 80) / len(sub)
                edge = (jumps[k - 1] if side == "top" else jumps[len(rows) - k - 1]) / med_jump
                if cons >= 0.95 and edge >= 6.0:
                    # 조건을 만족하는 것 중 가장 넓은 것이 띠의 실제 크기다
                    if best is None or frac > best["frac"]:
                        best = {"side": side, "frac": frac, "cons": cons,
                                "edge": edge, "color": base}

    has_band = best is not None
    band = best["frac"] if has_band else 0.0
    band_side = best["side"] if has_band else "top"
    band_color = tuple(int(v) for v in best["color"]) if has_band else None
    rest_cov = mean_cov

    if p98 >= 0.55:
        legib, veil, sure = "shadow", 0.22, True
    elif p98 < 0.35:
        legib, veil, sure = "veil", 0.5, True
    else:
        legib, veil, sure = "shadow", 0.3, False

    preset = "mono-type" if solid else ("color-band" if has_band else "photo-dump")

    return {
        "밝기_중앙": round(p50, 3), "밝기_p90": round(p90, 3), "밝기_p98": round(p98, 3),
        "단색점유율": round(mean_cov, 2), "띠밖_점유율": round(rest_cov, 2),
        "단색": solid, "밴드": has_band,
        "밴드_비율": round(band, 2), "밴드_위치": band_side,
        "추정_프리셋": preset,
        "추정_legibility": legib, "추정_veil": veil, "확실한가": sure,
        "밴드_색": band_color,
    }


def collect(paths, k=12):
    counter = Counter()
    for p in paths:
        im = Image.open(p).convert("RGB")
        im.thumbnail((400, 400))
        q = im.quantize(colors=k, method=Image.MEDIANCUT).convert("RGB")
        data = getattr(q, "get_flattened_data", None) or q.getdata
        counter.update(data())
    return [c for c, _ in counter.most_common(k * 2)]


def propose(colors, preset=None, band_color=None):
    """팔레트 4색을 고른다.

    **가장 흔한 색이 항상 배경인 것은 아니다.**
    사진 위에 글자를 얹는 레이아웃(photo-dump / magazine)에서는 배경이 거의 안 보이므로,
    가장 흔한 색은 보통 사진의 잡색(자갈·벽·하늘 평균)이다. 그걸 bg로 잡으면
    레퍼런스와 전혀 다른 카드가 나온다. 그래서 레이아웃에 따라 다르게 고른다.
    """
    if preset in ("photo-dump", "magazine"):
        # 사진이 주인공 — 배경은 사진의 어두운 앵커색, 글자는 흰색
        dark = [c for c in colors if lum(c) < 0.25]
        cand = [c for c in dark if saturation(c) >= 0.25] or dark or colors
        bg = min(cand, key=lum)
    elif preset == "color-band" and band_color:
        bg = band_color            # 띠 색을 직접 잰 값
    else:
        bg = colors[0]             # mono-type 등 — 가장 흔한 색이 실제 배경이다
    dark_bg = lum(bg) < 0.35

    ink = (255, 255, 255) if dark_bg else (26, 26, 26)

    accent, best = None, 0
    for c in colors[1:]:
        s = saturation(c)
        ct = contrast(c, bg)
        if s < 0.24 or ct < 4.5:
            continue
        score = s * min(ct, 8)
        if score > best:
            accent, best = c, score
    if accent is None:
        accent = (242, 169, 59) if dark_bg else (163, 78, 36)

    sub = tuple(int(i * 0.78 + b * 0.22) for i, b in zip(ink, bg))
    if contrast(sub, bg) < 4.5:
        sub = tuple(int(i * 0.9 + b * 0.1) for i, b in zip(ink, bg))

    return {"bg": rgb2hex(bg), "ink": rgb2hex(ink),
            "accent": rgb2hex(accent), "sub": rgb2hex(sub)}


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 1

    target = argv[1]
    as_json = "--json" in argv

    if os.path.isdir(target):
        paths = sorted(
            os.path.join(target, f) for f in os.listdir(target)
            if f.lower().endswith(EXTS)
        )
    else:
        paths = [target]

    if not paths:
        print(f"이미지가 없습니다: {target}", file=sys.stderr)
        return 1

    colors = collect(paths)
    m = measure(paths)
    pal = propose(colors, m["추정_프리셋"], m.get("밴드_색"))

    if as_json:
        print(json.dumps(pal, ensure_ascii=False, indent=2))
        return 0

    if "--style" in argv:
        pal2 = dict(pal)
        pal2.setdefault("chip", pal["accent"])
        draft = {
            "preset": m["추정_프리셋"],
            "_확인필요": [
                "preset 이 맞는지 이미지를 열어 확인할 것 (이 값은 추정이다)",
                "헤드라인이 명조면 preset 을 magazine 으로, type.family 를 serif 로 바꿀 것",
                "photo.legibility — 사진이 밝은데 흰 글자가 읽히면 shadow, 사진이 눌려 있으면 veil",
                "type.headline_cover — 레퍼런스에서 헤드라인이 폭의 몇 %를 먹는지 보고 조정",
                "decor — 말풍선·폴라로이드·스티커가 실제로 있는지, 계정 목적에 맞는지",
            ],
            "palette": pal2,
            "photo": {"legibility": m["추정_legibility"], "veil": m["추정_veil"]},
        }
        if m["밴드"]:
            draft["layout"] = {"mode": "band",
                               "band_height": round(m["밴드_비율"], 2),
                               "band_side": m["밴드_위치"]}
        print(json.dumps(draft, ensure_ascii=False, indent=2))
        return 0

    print(f"레퍼런스 {len(paths)}장 분석\n")
    for p in paths:
        print(f"  · {os.path.basename(p)}")
    print("\n많이 쓰인 색 (상위 8)")
    for c in colors[:8]:
        print(f"  {rgb2hex(c)}   채도 {saturation(c):.2f}")

    print("\n팔레트 제안")
    print(json.dumps(pal, ensure_ascii=False, indent=2))

    bgc = tuple(int(pal["bg"][i:i + 2], 16) for i in (1, 3, 5))
    print("\n대비 검사")
    for key, need in (("ink", 7.0), ("accent", 4.5), ("sub", 4.5)):
        c = tuple(int(pal[key][i:i + 2], 16) for i in (1, 3, 5))
        r = contrast(c, bgc)
        mark = "OK" if r >= need else "부족"
        print(f"  bg↔{key:6s} {r:5.1f}:1  (권장 {need}:1)  {mark}")

    print("\n구조 측정")
    print(f"  밝은쪽 끝 p98  {m['밝기_p98']:.3f}   " + (
        "막이 없다 → 글자 그림자로 읽히는 계열" if m['밝기_p98'] >= 0.55
        else ("막을 씌웠다 → veil 계열" if m['밝기_p98'] < 0.35
              else "애매하다 → 반드시 눈으로 확인할 것")))
    print(f"  (참고) 중앙 {m['밝기_중앙']:.3f} · p90 {m['밝기_p90']:.3f})")
    print(f"  단색 점유율    {m['단색점유율']:.2f}   (띠 밖 {m['띠밖_점유율']:.2f})")
    print(f"  단색 배경      {'예' if m['단색'] else '아니오'}")
    print(f"  가로 띠(밴드)  {'예' if m['밴드'] else '아니오'}"
          + (f"  ·  {m['밴드_위치']} {int(m['밴드_비율']*100)}%" if m['밴드'] else ""))
    print(f"\n  추정 프리셋 → {m['추정_프리셋']}"
          + ("" if m['확실한가'] else "   ⚠ 막 유무가 애매하다"))
    print("  * magazine(명조 헤드라인)은 기계가 못 가린다. 레퍼런스가 명조면 손으로 바꾼다.")

    print("""
다음 단계
  1. python3 analyze_reference.py <폴더> --style > 프로젝트루트/스타일.json
  2. 이미지를 직접 열어 references/reference-intake.md 체크리스트를 채운다
  3. 스크립트가 못 재는 항목(헤드라인 비율·정렬·장식)을 스타일.json에 손으로 넣는다
  4. 첫 장을 렌더해서 레퍼런스와 나란히 놓고 대조한다""")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
