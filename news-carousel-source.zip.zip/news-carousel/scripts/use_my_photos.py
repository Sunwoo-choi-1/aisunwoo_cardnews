#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""사용자가 직접 찍은 사진을 카드 배경으로 쓸 수 있게 다듬는다.

Pexels 대신(또는 함께) 쓴다. 매장·제품·현장 사진이 스톡 사진보다 나은 경우가 많다.

사용법:
    python3 use_my_photos.py <출력폴더> <사진파일 또는 폴더> ...

    # 예시
    python3 use_my_photos.py bg ../내사진
    python3 use_my_photos.py bg a.jpg b.png c.heic

하는 일:
    - 휴대폰 사진의 회전 정보(EXIF)를 실제로 반영한다.
      이걸 안 하면 세로로 찍은 사진이 옆으로 누워서 깔린다.
    - 너무 큰 사진을 카드 크기에 맞게 줄인다 (용량·속도)
    - 해상도가 모자란 사진은 경고한다. 늘려 쓰면 뿌옇게 나온다
    - bg_00.jpeg, bg_01.jpeg ... 로 저장하고 credits.json을 남긴다

내 사진은 출처 표기가 필요 없으므로 credits.json에는 원본 파일명만 적힌다.
"""

import json
import os
import sys

try:
    from PIL import Image, ImageOps
except ImportError:
    sys.exit("Pillow가 필요합니다:  pip install pillow")

EXT = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff", ".heic", ".heif"}
TARGET_W, TARGET_H = 1080, 1350
MAX_SIDE = 2200  # 이보다 크면 줄인다. 카드 한 장에 그 이상은 필요 없다.


def collect(sources):
    out = []
    for s in sources:
        s = os.path.expanduser(s)
        if os.path.isdir(s):
            for name in sorted(os.listdir(s)):
                if os.path.splitext(name)[1].lower() in EXT:
                    out.append(os.path.join(s, name))
        elif os.path.isfile(s) and os.path.splitext(s)[1].lower() in EXT:
            out.append(s)
    return out


def main(argv):
    if len(argv) < 3:
        print(__doc__.strip(), file=sys.stderr)
        return 2

    outdir, sources = argv[1], argv[2:]
    os.makedirs(outdir, exist_ok=True)

    files = collect(sources)
    if not files:
        print("쓸 수 있는 이미지를 찾지 못했습니다.", file=sys.stderr)
        print("  지원 형식: " + " ".join(sorted(EXT)), file=sys.stderr)
        return 1

    credits, low = [], []
    for i, src in enumerate(files):
        try:
            im = Image.open(src)
            im = ImageOps.exif_transpose(im)      # 휴대폰 회전 반영
            im = im.convert("RGB")
        except Exception as e:                     # HEIC 등 미지원 코덱
            print(f"  건너뜀: {os.path.basename(src)} ({e})", file=sys.stderr)
            continue

        w, h = im.size
        # 카드를 채우려면 가로·세로 배율 중 큰 쪽이 1.0 이상이어야 선명하다
        if min(w / TARGET_W, h / TARGET_H) < 1.0:
            low.append(f"{os.path.basename(src)} ({w}x{h})")

        if max(w, h) > MAX_SIDE:
            im.thumbnail((MAX_SIDE, MAX_SIDE), Image.LANCZOS)

        name = f"bg_{len(credits):02d}.jpeg"
        im.save(os.path.join(outdir, name), "JPEG", quality=92)
        credits.append({"file": name, "source": "내 사진", "original": os.path.basename(src)})
        print(f"  {name}  ←  {os.path.basename(src)}")

    if not credits:
        print("변환할 수 있는 이미지가 없었습니다.", file=sys.stderr)
        return 1

    with open(os.path.join(outdir, "credits.json"), "w", encoding="utf-8") as f:
        json.dump(credits, f, ensure_ascii=False, indent=2)

    print(f"\n{len(credits)}장 준비 완료 → {os.path.abspath(outdir)}")
    if low:
        print("\n해상도가 낮아 뿌옇게 나올 수 있는 사진:", file=sys.stderr)
        for x in low:
            print(f"  - {x}", file=sys.stderr)
        print(f"  권장: 가로 {TARGET_W}px, 세로 {TARGET_H}px 이상", file=sys.stderr)
        print("  이 사진은 글자를 크게 덮는 카드에 쓰거나 다른 사진으로 바꾸세요.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
