#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
stylekit.py — 스타일.json 을 읽고 프리셋과 합치는 공용 모듈.

cardgen.py(Chromium)와 render_cards.py(Pillow)가 같은 스타일 파일을 읽게 한다.
어느 렌더러로 그리든 색과 크기가 같아야 계정이 일관돼 보인다.

의존성 없음 — Pillow도 playwright도 import하지 않는다.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PRESET_DIR = os.path.normpath(os.path.join(HERE, "..", "assets", "presets"))

STICKER_CAP = {"none": 0, "light": 2, "rich": 5}

FALLBACK_STYLE = {
    "preset": "photo-dump",
    "canvas": {"size": [1080, 1350], "padding": 88},
    "palette": {"bg": "#15293B", "ink": "#FFFFFF", "accent": "#F5DFA8",
                "sub": "#DCE5EC", "chip": "#2E8FE8"},
    "type": {"family": "sans", "headline_cover": 132, "headline": 84, "body": 40,
             "cta": 46, "info": 28, "label": 30, "script": 60,
             "leading": 1.06, "tracking": -0.035},
    "layout": {"mode": "photo", "band_height": 0.44, "band_side": "top",
               "cover_anchor": "bottom", "body_anchor": "center", "align": "left"},
    "photo": {"legibility": "shadow", "veil": 0.22, "veil_color": None, "vignette": True},
    "decor": {"label": "pill", "chip": "bubble", "insets": 1, "stickers": "light",
              "script": "playfair", "page_number": True},
}


def deep_merge(base, over):
    out = dict(base)
    for k, v in (over or {}).items():
        if k.startswith("_"):
            continue
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        elif v is not None or k not in out:
            out[k] = v
    return out


def find_style(spec_dir):
    for cand in ("스타일.json", "style.json",
                 os.path.join("..", "스타일.json"), os.path.join("..", "style.json")):
        p = os.path.join(spec_dir, cand)
        if os.path.exists(p):
            return p
    return None


def load_style(spec_dir, style_path=None):
    """프리셋 < 스타일.json 순으로 덮어쓴다. 없으면 기본값으로 돈다."""
    if style_path is None:
        style_path = find_style(spec_dir)
    user = {}
    if style_path and os.path.exists(style_path):
        try:
            user = json.load(open(style_path, encoding="utf-8"))
        except json.JSONDecodeError as e:
            print(f"  ! 스타일.json을 읽지 못했습니다 ({e}). 기본값으로 진행합니다.",
                  file=sys.stderr)
            user = {}

    style = dict(FALLBACK_STYLE)
    name = user.get("preset", FALLBACK_STYLE["preset"])
    pp = os.path.join(PRESET_DIR, f"{name}.json")
    if os.path.exists(pp):
        style = deep_merge(style, json.load(open(pp, encoding="utf-8")))
    elif name:
        print(f"  ! 프리셋 '{name}'을 못 찾아 기본값으로 진행합니다", file=sys.stderr)
    style = deep_merge(style, user)
    style["_style_path"] = style_path
    return style


# ------------------------------------------------------------------ 폴백 변환

#: shadow 방식은 글자에 그림자를 넣어 읽히게 한다. Pillow 렌더러에는 그림자가 없으므로
#: 같은 사진을 쓰려면 막을 이만큼은 씌워야 글자가 읽힌다.
VEIL_FLOOR_WITHOUT_SHADOW = 0.45


def to_legacy_spec(spec, style):
    """스타일.json + 새 spec → render_cards.py(Pillow)가 읽는 옛 형식.

    Pillow 렌더러가 못 하는 것은 조용히 빼지 않고 무엇이 빠졌는지 돌려준다.
    """
    C, T, L, PH, D = (style["canvas"], style["type"], style["layout"],
                      style["photo"], style["decor"])
    P = style["palette"]
    dropped = set()

    out = dict(spec)
    out["size"] = C["size"]
    out["padding"] = C["padding"]
    out["palette"] = {k: P[k] for k in ("bg", "ink", "accent", "sub")}
    out["sizes"] = {k: T[k] for k in
                    ("headline_cover", "headline", "body", "cta", "info") if k in T}
    out["page_number"] = D.get("page_number", True)

    if T.get("family") == "serif":
        dropped.add("명조 헤드라인")
    if D.get("script", "none") != "none":
        dropped.add("스크립트 이탤릭")

    cards = []
    for c in spec.get("cards", []):
        c = dict(c)
        mode = c.pop("mode", L["mode"])

        if mode == "band":
            # 띠 레이아웃은 Pillow로 못 그린다. 사진을 빼고 단색 카드로 낮춘다.
            c.pop("bg_image", None)
            dropped.add("컬러밴드 레이아웃")
        elif mode == "solid":
            c.pop("bg_image", None)

        if c.get("bg_image"):
            veil = float(c.get("veil", PH["veil"]))
            if c.get("legibility", PH["legibility"]) == "shadow":
                if veil < VEIL_FLOOR_WITHOUT_SHADOW:
                    veil = VEIL_FLOOR_WITHOUT_SHADOW
                    dropped.add("글자 그림자 (대신 막을 씌움)")
            c["overlay"] = round(veil, 3)
            c["overlay_color"] = c.get("veil_color") or PH.get("veil_color") or P["bg"]

        for k in ("veil", "veil_color", "legibility", "band_height"):
            c.pop(k, None)
        if c.pop("script", None):
            pass
        if c.pop("chip", None):
            dropped.add("말풍선 칩")
        if c.pop("insets", None):
            dropped.add("폴라로이드 인서트")
        if c.pop("stickers", None):
            dropped.add("스티커")
        if D.get("label", "pill") == "none":
            c.pop("label", None)
        cards.append(c)

    out["cards"] = cards
    return out, sorted(dropped)
