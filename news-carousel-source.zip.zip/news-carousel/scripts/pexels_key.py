"""Pexels API 키 찾기.

찾는 순서
  1) 환경변수 PEXELS_API_KEY
  2) 카드뉴스-설정.md 의 `- API 키:` 줄
  3) 프로젝트 폴더 안 텍스트 파일에서 pexels·api·키 가 같이 있는 줄
  4) 프로젝트 폴더 안 텍스트 파일의 키 모양 문자열 (메모장에 그냥 붙여넣은 경우)
  5) 파일 이름 / 폴더 이름 자체가 키 모양

안내대로 설정 파일에 넣지 않아도 찾아낸다. 초보 사용자는 안내대로 하지 않고,
그때마다 "키를 못 찾았습니다"라고 하면 스킬이 쓸모없어진다.

키가 `없음`으로 적혀 있으면 사용자가 사진을 안 쓰겠다고 명시한 것이므로
("없음", 출처) 를 돌려준다. 호출하는 쪽은 단색 카드로 간다.

둘 다 없으면 (None, None).
"""

import os

import project

CONFIG_NAME = project.CONFIG_NAME
MAX_UP = 5


def find_config(start=None):
    """현재 폴더에서 위로 올라가며 카드뉴스-설정.md 를 찾는다."""
    d = os.path.abspath(start or os.getcwd())
    for _ in range(MAX_UP + 1):
        p = os.path.join(d, CONFIG_NAME)
        if os.path.isfile(p):
            return p
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return None


def key_from_config(path):
    """설정 파일에서 API 키 한 줄을 뽑는다. 없으면 None."""
    try:
        with open(path, encoding="utf-8") as f:
            text = f.read()
    except OSError:
        return None
    k = project.key_from_config_text(text)
    return None if k == "없음" else k


def resolve(start=None):
    """(키, 출처) 를 돌려준다. 사진을 쓰지 않기로 했으면 ("없음", 출처)."""
    env = os.environ.get("PEXELS_API_KEY", "").strip()
    if env:
        return env, "환경변수"

    # 설정 파일이 있는 폴더를 루트로 삼고, 없으면 근거로 추정한다.
    cfg = find_config(start)
    root = os.path.dirname(cfg) if cfg else project.find_root(cwd=start)
    if not root:
        return None, None

    return project.scan_key(root)


if __name__ == "__main__":
    k, src = resolve()
    print(f"{k}" if k and k != "없음" else "", end="")
