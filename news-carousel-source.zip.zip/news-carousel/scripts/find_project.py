#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""카드뉴스 작업 폴더가 이미 있는지 찾는다.

프로젝트 루트를 정하기 전에 돌린다. 이미 만들어둔 폴더를 못 찾고 새로 만들면
사용자는 "내가 만든 폴더는 왜 안 쓰지?" 라고 느끼고, 폴더가 두 개로 갈라진다.
그걸 막는 것이 이 스크립트의 전부다.

설정 파일이 없어도 찾는다. 사용자가 폴더만 먼저 만들어 둔 경우가 흔하기 때문이다.
아래 중 하나만 있으면 카드뉴스 작업 폴더로 본다.

    카드뉴스-설정.md  ·  스타일.json  ·  폴더 이름에 '카드뉴스'
    레퍼런스 폴더 (_레퍼런스 / 레퍼런스 / reference …)  ·  내사진 폴더

사용법:
    python3 find_project.py                # 기본 후보 폴더들을 훑는다
    python3 find_project.py /경로/A /경로/B  # 후보를 직접 지정한다

출력: JSON 한 줄 (종료코드 0)
    root        찾은 폴더
    evidence    그렇게 판단한 근거
    config      카드뉴스-설정.md 경로 (없으면 null)
    reference   레퍼런스 폴더 경로 (없으면 null)
    key_found   Pexels 키를 폴더 안에서 찾았는지
    key_source  키를 찾은 자리

못 찾으면 {"root": null} 한 줄 (종료코드 1)
"""

import json
import os
import sys

import project


def main(argv):
    roots = argv[1:] or None
    root = project.find_root(roots)

    if not root:
        print(json.dumps({"root": None}, ensure_ascii=False))
        return 1

    cfg = os.path.join(root, project.CONFIG_NAME)
    key, src = project.scan_key(root)

    print(json.dumps({
        "root": root,
        "evidence": project.root_evidence(root),
        "config": cfg if os.path.isfile(cfg) else None,
        "reference": project.reference_dir(root),
        "key_found": bool(key and key != "없음"),
        "key_source": src,
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
