#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
spec.json → 인스타그램 카드뉴스 PNG.

사용법:
    python3 render_cards.py spec.json

의존성: Pillow, 한글 폰트(Noto Sans CJK KR 또는 나눔고딕)
    pip install pillow
    apt-get install -y fonts-noto-cjk     # 없으면 글자가 □□□로 나온다

이 스크립트는 다른 스킬에 의존하지 않는다. spec.json 하나만 있으면 돈다.
"""

import json
import os
import sys

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    sys.exit("Pillow가 없습니다:  pip install pillow")

# ---------------------------------------------------------------- 폰트

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import fontfind
except ImportError:
    sys.exit("fontfind.py가 같은 폴더에 있어야 합니다.")

_font_cache = {}
_resolved = {}


def font(weight, size):
    key = (weight, size)
    if key in _font_cache:
        return _font_cache[key]
    if weight not in _resolved:
        _resolved[weight] = fontfind.find(weight)
    path, idx = _resolved[weight]
    if path is None:
        sys.exit(fontfind.INSTALL_HINT)
    f = ImageFont.truetype(path, size, index=idx)
    _font_cache[key] = f
    return f


# ---------------------------------------------------------------- 유틸

def hex2rgb(h):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def luminance(rgb):
    def ch(c):
        c /= 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = luminance(hex2rgb(a)), luminance(hex2rgb(b))
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def text_w(draw, s, f):
    if not s:
        return 0
    return draw.textbbox((0, 0), s, font=f)[2]


NO_LEAD = set(",.!?)]}·%…’”")


def wrap(draw, text, f, maxw):
    """어절 단위 줄바꿈. \n은 강제 개행으로 존중한다."""
    out = []
    for para in text.split("\n"):
        if not para.strip():
            out.append("")
            continue
        line = ""
        for word in para.split(" "):
            trial = f"{line} {word}".strip()
            if text_w(draw, trial, f) <= maxw or not line:
                line = trial
            else:
                out.append(line)
                line = word
        if line:
            out.append(line)
    # 문장부호가 줄 첫머리에 오면 앞줄로 당긴다
    for i in range(1, len(out)):
        while out[i] and out[i][0] in NO_LEAD:
            out[i - 1] += out[i][0]
            out[i] = out[i][1:].lstrip()
    return [l for l in out if l != "" or len(out) == 1]


def fit(draw, text, weight, start, maxw, maxh, line_gap, minimum):
    """지정 크기로 안 들어가면 4pt씩 줄인다. (폰트, 줄목록, 줄높이) 반환."""
    size = start
    while size >= minimum:
        f = font(weight, size)
        lines = wrap(draw, text, f, maxw)
        lh = int(size * line_gap)
        if len(lines) * lh <= maxh:
            return f, lines, lh, size
        size -= 4
    f = font(weight, minimum)
    return f, wrap(draw, text, f, maxw), int(minimum * line_gap), minimum


def draw_accented(draw, xy, line, f, base, accent, words):
    """한 줄을 그리되 accent_words에 해당하는 부분만 다른 색으로."""
    x, y = xy
    if not words:
        draw.text((x, y), line, font=f, fill=base)
        return
    idx, n = 0, len(line)
    while idx < n:
        hit = None
        for w in words:
            if w and line.startswith(w, idx):
                if hit is None or len(w) > len(hit):
                    hit = w
        if hit:
            draw.text((x, y), hit, font=f, fill=accent)
            x += text_w(draw, hit, f)
            idx += len(hit)
        else:
            draw.text((x, y), line[idx], font=f, fill=base)
            x += text_w(draw, line[idx], f)
            idx += 1


def cover_crop(im, w, h):
    iw, ih = im.size
    scale = max(w / iw, h / ih)
    im = im.resize((max(1, int(iw * scale)), max(1, int(ih * scale))), Image.LANCZOS)
    iw, ih = im.size
    return im.crop(((iw - w) // 2, (ih - h) // 2, (iw - w) // 2 + w, (ih - h) // 2 + h))


# ---------------------------------------------------------------- 렌더

DEFAULT_SIZES = {
    "headline_cover": 104, "headline": 72, "body": 40,
    "cta": 46, "info": 30, "label": 30,
}


def render_card(card, spec, index, total):
    W, H = spec.get("size", [1080, 1350])
    pad = spec.get("padding", 80)
    pal = spec["palette"]
    S = dict(DEFAULT_SIZES, **spec.get("sizes", {}))

    img = Image.new("RGB", (W, H), hex2rgb(pal["bg"]))
    on_photo = False

    bgp = card.get("bg_image")
    if bgp and os.path.exists(bgp):
        photo = cover_crop(Image.open(bgp).convert("RGB"), W, H)
        img.paste(photo, (0, 0))
        ov = float(card.get("overlay", 0.45))
        if ov > 0:
            veil = Image.new("RGB", (W, H), hex2rgb(card.get("overlay_color", "#000000")))
            img = Image.blend(img, veil, min(max(ov, 0.0), 1.0))
        on_photo = True
    elif bgp:
        print(f"  ! 배경 없음: {bgp} — 단색으로 그립니다", file=sys.stderr)

    ink = card.get("ink_on_photo", "#FFFFFF") if on_photo else pal["ink"]
    sub = card.get("sub_on_photo", "#E8E8E8") if on_photo else pal["sub"]
    accent = pal["accent"]
    draw = ImageDraw.Draw(img)

    maxw = W - pad * 2
    is_cover = card.get("type") == "cover"
    hsize = S["headline_cover"] if is_cover else S["headline"]

    blocks = []  # (종류, 폰트, 줄목록, 줄높이, 색, 여백)

    if card.get("label"):
        f = font("bold", S["label"])
        blocks.append(("label", f, [card["label"]], int(S["label"] * 1.3), accent, 28))

    if card.get("headline"):
        f, lines, lh, used = fit(
            draw, card["headline"], "bold", hsize, maxw, int(H * 0.46), 1.25, 40
        )
        if used < hsize - 8:
            print(f"  · {index+1}번 헤드라인 자동 축소 {hsize}→{used} (문장을 줄이는 편이 낫습니다)",
                  file=sys.stderr)
        blocks.append(("headline", f, lines, lh, ink, 28))

    if card.get("body"):
        f, lines, lh, _ = fit(draw, card["body"], "regular", S["body"], maxw, int(H * 0.28), 1.5, 28)
        blocks.append(("body", f, lines, lh, sub, 20))

    for b in card.get("bullets", []):
        f = font("regular", S["body"])
        lines = wrap(draw, b, f, maxw - 34)
        blocks.append(("bullet", f, lines, int(S["body"] * 1.5), sub, 12))

    if card.get("cta"):
        f, lines, lh, _ = fit(draw, card["cta"], "bold", S["cta"], maxw, int(H * 0.2), 1.4, 32)
        blocks.append(("cta", f, lines, lh, accent, 20))

    if card.get("info"):
        f = font("regular", S["info"])
        lines = wrap(draw, card["info"], f, maxw)
        blocks.append(("info", f, lines, int(S["info"] * 1.5), sub, 0))

    total_h = sum(len(l) * lh + gap for _, _, l, lh, _, gap in blocks)
    footer = pad + 46
    if is_cover:
        y = H - footer - total_h
    else:
        y = (H - total_h) // 2
    y = max(y, pad)

    for kind, f, lines, lh, color, gap in blocks:
        if kind == "label":
            tw = text_w(draw, lines[0], f)
            draw.rounded_rectangle(
                [pad, y - 6, pad + tw + 36, y + lh + 2], radius=(lh + 8) // 2,
                fill=hex2rgb(accent),
            )
            draw.text((pad + 18, y), lines[0], font=f, fill=hex2rgb(pal["bg"]))
            y += lh + gap
            continue
        for ln in lines:
            x = pad
            if kind == "bullet":
                r = max(4, f.size // 8)
                cy = y + lh // 2 - r
                draw.ellipse([pad, cy, pad + r * 2, cy + r * 2], fill=hex2rgb(accent))
                x = pad + 34
            if kind == "headline":
                draw_accented(draw, (x, y), ln, f, hex2rgb(color), hex2rgb(accent),
                              card.get("accent_words", []))
            else:
                draw.text((x, y), ln, font=f, fill=hex2rgb(color))
            y += lh
        y += gap

    # 푸터
    fs = font("regular", 28)
    if spec.get("brand"):
        draw.text((pad, H - pad - 28), spec["brand"], font=fs, fill=hex2rgb(sub))
    if spec.get("page_number", True):
        s = f"{index + 1} / {total}"
        draw.text((W - pad - text_w(draw, s, fs), H - pad - 28), s, font=fs, fill=hex2rgb(sub))

    return img


def main(spec_path):
    with open(spec_path, encoding="utf-8") as f:
        spec = json.load(f)

    if "cards" not in spec:
        sys.exit("spec.json에 'cards'가 없습니다.")

    # 스타일.json 형식이면 옛 형식으로 낮춰서 그린다.
    # (Chromium이 없는 환경의 폴백 경로 — 무엇이 빠졌는지 반드시 알린다)
    if "palette" not in spec:
        try:
            from stylekit import load_style, to_legacy_spec
        except ImportError:
            sys.exit("stylekit.py가 scripts/ 폴더에 있어야 합니다.")
        style = load_style(os.path.dirname(os.path.abspath(spec_path)))
        spec, dropped = to_legacy_spec(spec, style)
        print(f"  폴백 렌더러 · 프리셋 {style.get('preset','?')}")
        if dropped:
            print("  · 이 환경에서 빠진 것: " + ", ".join(dropped), file=sys.stderr)
            print("  · 레퍼런스대로 뽑으려면 Chromium이 필요합니다"
                  " (pip install playwright && playwright install chromium)", file=sys.stderr)

    pal = spec["palette"]
    for a, b, need in (("bg", "ink", 7.0), ("bg", "accent", 4.5), ("bg", "sub", 4.5)):
        c = contrast(pal[a], pal[b])
        if c < need:
            print(f"  ! 대비 부족 {a}↔{b} = {c:.1f}:1 (권장 {need}:1 이상)", file=sys.stderr)

    outdir = spec.get("output_dir", ".")
    os.makedirs(outdir, exist_ok=True)
    cards = spec["cards"]

    for i, card in enumerate(cards):
        img = render_card(card, spec, i, len(cards))
        name = card.get("filename") or f"{i + 1:02d}.png"
        path = os.path.join(outdir, name)
        img.save(path, "PNG")
        print(f"  {name}  {os.path.getsize(path) // 1024}KB")

    print(f"\n{len(cards)}장 완료 → {os.path.abspath(outdir)}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    sys.exit(main(sys.argv[1]))
