#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cardgen.py — 카드뉴스 HTML 렌더러 (헤드리스 Chromium)

Pillow 렌더러(render_cards.py)가 못 하는 것을 그린다.
  · 글자 그림자      → 사진을 어둡게 안 덮어도 읽힌다 (레퍼런스 재현의 핵심)
  · 컬러밴드 레이아웃 → 글자를 띠 안에, 사진은 손대지 않고
  · 명조 헤드라인
  · 말풍선 칩(꼬리 포함) / 폴라로이드 인서트 / 스티커
  · 스크립트 이탤릭 한 줄

스타일과 내용을 분리한다.
  스타일.json = 계정 생김새 (레퍼런스 분석 결과, 한 번 정하면 계속)
  spec.json   = 그날 내용

사용:
  python3 cardgen.py spec.json                       # 옆의 스타일.json을 자동으로 찾는다
  python3 cardgen.py spec.json --style ../스타일.json
  python3 cardgen.py --check                         # 이 환경에서 쓸 수 있는지만 확인
"""
import base64
import json
import mimetypes
import os
import socket
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from stylekit import load_style, STICKER_CAP  # noqa: E402

ASSETS = os.path.normpath(os.path.join(HERE, "..", "assets"))
EMOJI_DIR = os.path.join(ASSETS, "emoji")

#: 한글이 있는 시스템 폰트를 우선순위대로. 앞에서부터 있는 것이 잡힌다.
FAMILY = {
    "sans": "'Noto Sans CJK KR','Noto Sans KR','Apple SD Gothic Neo',"
            "'Malgun Gothic','맑은 고딕','NanumGothic',sans-serif",
    "serif": "'Noto Serif CJK KR','Noto Serif KR','AppleMyungjo',"
             "'Batang','바탕','NanumMyeongjo',serif",
}

# ------------------------------------------------------------------ 환경

def capability():
    """이 환경에서 cardgen을 쓸 수 있는지. (가능여부, 사유)"""
    try:
        from playwright.sync_api import sync_playwright  # noqa
    except ImportError:
        return False, "playwright 미설치"
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            pw.chromium.launch().close()
        return True, "정상"
    except Exception as e:
        msg = str(e).splitlines()[0][:90]
        return False, f"Chromium 실행 불가 — {msg}"


def online(host="fonts.googleapis.com", port=443, timeout=2.5):
    try:
        socket.create_connection((host, port), timeout).close()
        return True
    except OSError:
        return False


# ------------------------------------------------------------------ 자원

def data_uri(path, base):
    if not path:
        return None
    p = path if os.path.isabs(path) else os.path.normpath(os.path.join(base, path))
    if not os.path.exists(p):
        print(f"  ! 이미지를 못 찾았습니다: {path}", file=sys.stderr)
        return None
    mime = mimetypes.guess_type(p)[0] or "image/jpeg"
    with open(p, "rb") as f:
        return f"data:{mime};base64," + base64.b64encode(f.read()).decode()


_emoji_index = None
_emoji_svg = None


def _svg_source(code):
    """코드에 해당하는 Twemoji SVG 본문. 없으면 None.

    두 군데를 본다.
      1) assets/emoji/<code>.svg          — 낱개 파일
      2) assets/emoji-svg.json            — 낱개 파일을 한 파일에 담아둔 것

    2번이 있는 이유: 스킬 업로더가 .svg 를 '스킬 파일이 아님'으로 걸러낸다.
    낱개 파일은 설치 과정에서 사라지므로 JSON 쪽이 실제로 쓰이는 경로다.
    """
    global _emoji_svg

    p = os.path.join(EMOJI_DIR, f"{code}.svg")
    if os.path.exists(p):
        return open(p, encoding="utf-8").read()

    if _emoji_svg is None:
        bundle = os.path.join(ASSETS, "emoji-svg.json")
        try:
            _emoji_svg = json.load(open(bundle, encoding="utf-8"))
        except (OSError, ValueError):
            _emoji_svg = {}
    return _emoji_svg.get(code)


def emoji_html(ch, size):
    """이모지를 스킬에 든 Twemoji SVG로 그린다.
    없으면 시스템 이모지 폰트로 떨어지고, 그것도 없으면 호출한 쪽에서 뺀다."""
    global _emoji_index
    if _emoji_index is None:
        idx = os.path.join(EMOJI_DIR, "index.json")
        _emoji_index = json.load(open(idx, encoding="utf-8")) if os.path.exists(idx) else {}
    key = ch if ch in _emoji_index else ch.replace("️", "")
    code = _emoji_index.get(key)
    if code:
        svg = _svg_source(code)
        if svg:
            b64 = base64.b64encode(svg.encode("utf-8")).decode()
            return (f'<img class="em" src="data:image/svg+xml;base64,{b64}" '
                    f'style="width:{size}px;height:{size}px">')
    return f'<span class="em-font" style="font-size:{size}px">{esc(ch)}</span>'


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def accented(text, words):
    out = esc(text)
    for w in sorted([w for w in (words or []) if w], key=len, reverse=True):
        ew = esc(w)
        if ew in out:
            out = out.replace(ew, f"\x00{ew}\x01", 1)
    out = out.replace("\x00", '<span class="ac">').replace("\x01", "</span>")
    return out.replace("\n", "<br>")


# ------------------------------------------------------------------ CSS

CSS = """
*{margin:0;padding:0;box-sizing:border-box}
html,body{background:#000}
.card{position:relative;overflow:hidden;-webkit-font-smoothing:antialiased}
.photo{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.veil{position:absolute;inset:0}
.vig{position:absolute;inset:0;background:linear-gradient(to bottom,
     rgba(0,0,0,.28) 0%,rgba(0,0,0,0) 24%,rgba(0,0,0,0) 60%,rgba(0,0,0,.44) 100%)}
.split{position:absolute;inset:0;display:flex;flex-direction:column}
.split.bottom{flex-direction:column-reverse}
.split .band{flex:none;position:relative}
.split .pane{flex:1;position:relative;overflow:hidden;min-height:0}
.split .pane img{width:100%;height:100%;object-fit:cover;display:block}
.stage{position:absolute;inset:0;display:flex;flex-direction:column}
.slot{flex:1;display:flex;flex-direction:column;min-height:0}
.slot.top{justify-content:flex-start}
.slot.center{justify-content:center}
.slot.bottom{justify-content:flex-end}
.al-center{text-align:center}
.al-center .label,.al-center .chip{align-self:center}
.al-center li{justify-content:center}

.label{display:inline-block;align-self:flex-start;border-radius:999px;font-weight:900;
       line-height:1;white-space:nowrap}
h1{font-weight:900}
h1 .ac{color:var(--accent)}
.script{font-family:'Playfair Display',Georgia,'Times New Roman',serif;font-style:italic;
        font-weight:500;line-height:1;letter-spacing:-.01em}
p.body,li{font-weight:500;line-height:1.5;letter-spacing:-.015em}
ul{list-style:none}
li{display:flex;gap:.5em;text-align:left}
li::before{content:"";flex:none;width:.34em;height:.34em;border-radius:50%;
           background:var(--accent);margin-top:.62em}
.cta{font-weight:900;letter-spacing:-.02em;line-height:1.3}
.info{font-weight:400;line-height:1.5;letter-spacing:-.01em;opacity:.92}

.shadowed h1{text-shadow:0 2px 6px rgba(0,0,0,.42),0 6px 34px rgba(0,0,0,.55)}
.shadowed .script{text-shadow:0 2px 6px rgba(0,0,0,.42),0 6px 26px rgba(0,0,0,.5)}
.shadowed p.body,.shadowed li,.shadowed .foot{
       text-shadow:0 1px 4px rgba(0,0,0,.5),0 3px 18px rgba(0,0,0,.5)}
.shadowed .cta{text-shadow:0 2px 6px rgba(0,0,0,.45),0 4px 22px rgba(0,0,0,.5)}
.shadowed .info{text-shadow:0 1px 4px rgba(0,0,0,.55)}

.chip{position:relative;align-self:flex-start;display:inline-flex;align-items:center;gap:.42em;
      border-radius:999px;font-weight:700;line-height:1;white-space:nowrap;color:#fff;
      box-shadow:0 6px 20px rgba(0,0,0,.28)}
.chip.tail::after{content:"";position:absolute;left:17px;bottom:-8px;width:19px;height:19px;
      background:inherit;border-radius:0 0 6px 0;transform:rotate(22deg) skewX(-8deg)}
.em{display:inline-block;vertical-align:-.14em}
.em-font{font-family:'Noto Color Emoji','Apple Color Emoji','Segoe UI Emoji',sans-serif}

.inset{position:absolute;background:#fff;padding:8px 8px 0 8px;border-radius:3px;
       box-shadow:0 10px 30px rgba(0,0,0,.32);z-index:3}
.inset img{display:block;width:100%;aspect-ratio:1/1.12;object-fit:cover}
.inset .cap{font-weight:800;text-align:center;color:#1b1b1b;letter-spacing:.04em;
            padding:7px 0 8px;line-height:1}
.sticker{position:absolute;line-height:1;z-index:3;
         filter:drop-shadow(0 4px 10px rgba(0,0,0,.3))}
.sticker img{display:block;width:100%;height:100%}

.foot{display:flex;justify-content:space-between;align-items:flex-end;font-weight:500}
"""

FIT_JS = """
(function(){
  document.querySelectorAll('[data-fit]').forEach(function(el){
    var box=el.parentElement, maxH=parseFloat(el.dataset.maxh);
    var want=parseFloat(el.dataset.fit), min=parseFloat(el.dataset.min||40), size=want, g=0;
    el.style.fontSize=size+'px';
    while(g++<220 && size>min &&
          (el.scrollWidth>box.clientWidth+1 || el.getBoundingClientRect().height>maxH)){
      size-=2; el.style.fontSize=size+'px';
    }
    if(size<want-6) console.log('SHRINK|'+el.dataset.name+'|'+want+'|'+size);
  });
  document.documentElement.dataset.ready='1';
})();
"""


# ------------------------------------------------------------------ 카드

def card_html(card, spec, style, index, total, base):
    C, T, L, PH, D = (style["canvas"], style["type"], style["layout"],
                      style["photo"], style["decor"])
    P = style["palette"]
    W, H = C["size"]
    pad = C["padding"]
    mode = card.get("mode", L["mode"])
    kind = card.get("type", "body")
    is_cover = kind == "cover"
    anchor = L["cover_anchor"] if is_cover else L["body_anchor"]
    ce = ""

    img = data_uri(card.get("bg_image"), base) if mode != "solid" else None
    if mode == "photo" and not img:
        mode = "solid"

    legib = card.get("legibility", PH["legibility"])
    shadowed = (mode == "photo" and legib == "shadow")

    # --- 배경 레이어
    layers, band_style, text_w = "", "", W - pad * 2
    if mode == "photo":
        veil = float(card.get("veil", PH["veil"]))
        vc = card.get("veil_color") or PH.get("veil_color") or P["bg"]
        layers = (f'<img class="photo" src="{img}">'
                  f'<div class="veil" style="background:{vc};opacity:{veil}"></div>')
        if PH.get("vignette", True):
            layers += '<div class="vig"></div>'
    elif mode == "band":
        bh = float(card.get("band_height", L.get("band_height", 0.44)))
        side = L.get("band_side", "top")
        pane = f'<div class="pane"><img src="{img}"></div>' if img else '<div class="pane"></div>'
        layers = (f'<div class="split {"bottom" if side == "bottom" else ""}">'
                  f'<div class="band" style="height:{round(bh*100,2)}%;background:{P["bg"]}"></div>'
                  f'{pane}</div>')
        band_style = f"height:{round(bh*100, 2)}%;" + (
            "top:auto;bottom:0;" if side == "bottom" else "top:0;bottom:auto;")

    # --- 글자 블록
    parts = []
    if card.get("label") and D.get("label", "pill") != "none":
        s = T["label"]
        parts.append(f'<div class="label" style="background:{P["accent"]};color:{P["bg"]};'
                     f'font-size:{s}px;padding:{int(s*.52)}px {int(s*.86)}px;'
                     f'margin-bottom:{s}px"{ce}>{esc(card["label"])}</div>')

    if card.get("headline"):
        hs = T["headline_cover"] if is_cover else T["headline"]
        parts.append(
            f'<h1 data-fit="{hs}" data-min="44" data-maxh="{int(H*0.5)}" data-name="{index+1}"'
            f' style="color:{P["ink"]};line-height:{T["leading"]};'
            f'letter-spacing:{T["tracking"]}em;margin-bottom:{int(hs*0.22)}px"{ce}>'
            f'{accented(card["headline"], card.get("accent_words"))}</h1>')

    if card.get("script") and D.get("script", "none") != "none":
        s = T["script"]
        parts.append(f'<div class="script" style="color:{P["accent"]};font-size:{s}px;'
                     f'margin:-{int(s*0.26)}px 0 {int(s*0.42)}px"{ce}>{esc(card["script"])}</div>')

    if card.get("body"):
        s = T["body"]
        parts.append(f'<p class="body" style="color:{P["sub"]};font-size:{s}px;'
                     f'margin-bottom:{int(s*0.6)}px"{ce}>{esc(card["body"])}</p>')

    if card.get("bullets"):
        s = T["body"]
        lis = "".join(f'<li style="margin-bottom:{int(s*0.34)}px"><span{ce}>{esc(b)}</span></li>'
                      for b in card["bullets"])
        parts.append(f'<ul style="color:{P["sub"]};font-size:{s}px;'
                     f'margin-bottom:{int(s*0.5)}px">{lis}</ul>')

    if card.get("cta"):
        s = T["cta"]
        parts.append(f'<div class="cta" style="color:{P["accent"]};font-size:{s}px;'
                     f'margin-bottom:{int(s*0.5)}px"{ce}>{esc(card["cta"])}</div>')

    if card.get("info"):
        parts.append(f'<div class="info" style="color:{P["sub"]};font-size:{T["info"]}px"{ce}>'
                     f'{esc(card["info"])}</div>')

    chip, chip_mode = card.get("chip"), D.get("chip", "bubble")
    if chip and chip_mode != "none":
        cs = int(chip.get("size", 34))
        em = emoji_html(chip["emoji"], int(cs * 1.06)) if chip.get("emoji") else ""
        parts.append(
            f'<div class="chip {"tail" if chip_mode == "bubble" else ""}" '
            f'style="background:{chip.get("color", P["chip"])};font-size:{cs}px;'
            f'padding:{int(cs*.58)}px {int(cs*.86)}px;margin-top:{int(cs*.6)}px">'
            f'<span{ce}>{esc(chip["text"])}</span>{em}</div>')

    # --- 절대배치 장식 (사진 위에만 의미가 있다)
    deco = ""
    if mode != "solid":
        for it in (card.get("insets") or [])[:int(D.get("insets", 0))]:
            src = data_uri(it.get("image"), base)
            if not src:
                continue
            cap = (f'<div class="cap" style="font-size:{it.get("cap_size",22)}px">'
                   f'{esc(it["label"])}</div>') if it.get("label") else ""
            deco += (f'<div class="inset" style="left:{it.get("x",70)}%;top:{it.get("y",12)}%;'
                     f'width:{it.get("w",22)}%;transform:rotate({it.get("rot",0)}deg)">'
                     f'<img src="{src}">{cap}</div>')
        cap_n = STICKER_CAP.get(D.get("stickers", "none"), 0)
        for st in (card.get("stickers") or [])[:cap_n]:
            sz = st.get("size", 48)
            deco += (f'<div class="sticker" style="left:{st.get("x",50)}%;top:{st.get("y",50)}%;'
                     f'width:{sz}px;height:{sz}px;transform:translate(-50%,-50%) '
                     f'rotate({st.get("rot",0)}deg)">{emoji_html(st["emoji"], sz)}</div>')

    foot = ""
    show_pg = D.get("page_number", True)
    if spec.get("brand") or show_pg:
        left = f'<span{ce}>{esc(spec.get("brand",""))}</span>' if spec.get("brand") else "<span></span>"
        right = f"<span>{index+1} / {total}</span>" if show_pg else "<span></span>"
        foot = (f'<div class="foot" style="color:{P["sub"]};font-size:28px;'
                f'padding-top:{int(pad*0.5)}px">{left}{right}</div>')

    stage = (f'<div class="stage {"al-center" if L.get("align")=="center" else ""}" '
             f'style="padding:{pad}px;{band_style}">'
             f'<div class="slot {anchor}"><div>{"".join(parts)}</div></div>{foot}</div>')

    return (f'<div class="card {"shadowed" if shadowed else ""}" '
            f'style="width:{W}px;height:{H}px;background:{P["bg"]};'
            f'font-family:{FAMILY.get(T.get("family","sans"), FAMILY["sans"])};'
            f'--accent:{P["accent"]}">{layers}{deco}{stage}</div>')


def page(body, want_script, extra_css="", extra_body=""):
    link = ('<link href="https://fonts.googleapis.com/css2?'
            'family=Playfair+Display:ital,wght@1,500;1,600&display=swap" rel="stylesheet">'
            if want_script else "")
    return (f'<!doctype html><html><head><meta charset="utf-8">{link}'
            f"<style>{CSS}{extra_css}</style></head><body>{body}{extra_body}"
            f"<script>{FIT_JS}</script></body></html>")


# ------------------------------------------------------------------ 렌더

def render(spec_path, style_path=None, only=None):
    from playwright.sync_api import sync_playwright

    base = os.path.dirname(os.path.abspath(spec_path))
    spec = json.load(open(spec_path, encoding="utf-8"))
    style = load_style(base, style_path)
    W, H = style["canvas"]["size"]
    cards = spec["cards"]
    outdir = os.path.normpath(os.path.join(base, spec.get("output_dir", ".")))
    os.makedirs(outdir, exist_ok=True)

    want_script = (style["decor"].get("script", "none") != "none"
                   and any(c.get("script") for c in cards))
    net = online() if want_script else False
    if want_script and not net:
        print("  · 인터넷이 없어 스크립트 서체는 기본 명조로 대체됩니다", file=sys.stderr)

    print(f"  프리셋 {style.get('preset','?')} · {style['layout']['mode']} 레이아웃 · "
          f"글자 {style['photo']['legibility']}")

    warned = []
    drawn = 0
    with sync_playwright() as pw:
        browser = pw.chromium.launch(args=["--font-render-hinting=none"])
        pg = browser.new_page(viewport={"width": W, "height": H}, device_scale_factor=1)
        pg.on("console", lambda m: warned.append(m.text) if m.text.startswith("SHRINK|") else None)

        for i, c in enumerate(cards):
            # --only N 이면 그 카드만 그린다. 페이지 번호는 전체 기준을 유지한다.
            if only and (i + 1) not in only:
                continue
            drawn += 1
            html = page(card_html(c, spec, style, i, len(cards), base), want_script and net)
            pg.set_content(html, wait_until="networkidle" if net else "load")
            pg.wait_for_function("document.documentElement.dataset.ready === '1'")
            pg.wait_for_timeout(160)
            name = c.get("filename") or f"{i+1:02d}.png"
            path = os.path.join(outdir, name)
            pg.locator(".card").screenshot(path=path)
            print(f"  {name}  {os.path.getsize(path)//1024}KB")

        browser.close()

    for w in warned:
        _, n, want, got = w.split("|")
        print(f"  · {n}번 헤드라인 자동 축소 {want}→{got} (문장을 줄이는 편이 낫습니다)",
              file=sys.stderr)
    note = f" (전체 {len(cards)}장 중 일부)" if only else ""
    print(f"\n{drawn}장 완료{note} → {outdir}")


if __name__ == "__main__":
    args = sys.argv[1:]
    if "--check" in args:
        ok, why = capability()
        print(("사용 가능" if ok else "사용 불가") + f" — {why}")
        sys.exit(0 if ok else 1)
    if not args:
        sys.exit("사용: python3 cardgen.py spec.json [--style 스타일.json] "
                 "[--only 1] [--only 1,3]")
    sp = args[0]
    st = args[args.index("--style") + 1] if "--style" in args else None

    only = None
    if "--only" in args:
        try:
            raw = args[args.index("--only") + 1]
            only = {int(x) for x in raw.replace(" ", "").split(",") if x}
        except (IndexError, ValueError):
            sys.exit("--only 뒤에는 카드 번호를 적습니다.  예: --only 1  /  --only 1,3")
        if not only:
            sys.exit("--only 뒤에는 카드 번호를 적습니다.  예: --only 1")

    render(sp, st, only)
